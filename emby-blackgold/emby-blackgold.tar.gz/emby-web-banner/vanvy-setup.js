/*!
 * vanvy-setup.js — Emby 影院黑金横幅 + 毛玻璃主题 统一加载器
 * 职责: 依序加载 Vanvy 核心(vanvy-core / carousel-rules) → 影院横幅(banner_cinema)
 *       → 全局毛玻璃黑金主题(glass_graphite)
 * 设计: defer 脚本, 全部动态注入, 失败不阻塞 Emby 本体。幂等。
 */
(function () {
  'use strict';
  if (window.VanvySetupLoaded) return;
  window.VanvySetupLoaded = true;

  var BASE = 'vanvy/';   // 相对 /web/ 根, index.html 同址

  function log() {
    try { console.log('[vanvy-setup]', [].slice.call(arguments).join(' ')); } catch (e) {}
  }

  /** 动态加载 js */
  function loadJS(src) {
    return new Promise(function (resolve) {
      var s = document.createElement('script');
      s.src = BASE + src + '?v=epsort_20260817_050145';
      s.onload = function () { resolve(true); };
      s.onerror = function () { log('加载失败: ' + src); resolve(false); };
      document.head.appendChild(s);
    });
  }
  /** 动态加载 css */
  function loadCSS(href) {
    return new Promise(function (resolve) {
      var l = document.createElement('link');
      l.rel = 'stylesheet';
      l.href = BASE + href + '?v=epsort_20260817_050145';
      l.onload = function () { resolve(true); };
      l.onerror = function () { resolve(false); };
      document.head.appendChild(l);
    });
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  async function setup() {
    log('开始部署 Vanvy 影院黑金…');

    // 1. 注入黑金主题 class 到 body(默认 midnight 黑金, 观感最佳)
    //    banner_cinema 从 body/html class 读主题
    var theme = 'midnight';
    try {
      var stored = localStorage.getItem('vanvy-aurora-theme') || '';
      if (/^(midnight|emerald|sakura|gold|aurora|ember|sky)$/.test(stored)) theme = stored;
    } catch (e) {}
    document.body.classList.add('vanvy-aurora-theme-' + theme);
    log('主题: ' + theme);

    // 2. 加载 glass_graphite 毛玻璃基座(css) + 激活 js
    await loadCSS('themes/glass_graphite.css');
    loadJS('themes/theme-glass_graphite.js');

    // 3. 加载核心: vanvy-core (ApiClient 通信) → carousel-rules(轮播数据)
    await loadJS('core/vanvy-core.js');
    await loadJS('carousel_rules/rules-loader.js');

    // 4. 加载影院横幅 css + js
    await loadCSS('banner_cinema/style.css');
    await loadJS('banner_cinema/banner-cinema.js');

    // 5. 高质感纯黑全局覆盖层(最后加载, 最高优先级; 注意它在 web根 不在 vanvy/ 子目录)
    // 绝对路径(web 根), 避免相对路径在 hash 路由下解析错
    var black = document.createElement('link'); black.rel='stylesheet'; black.href='/web/vanvy-black.css?v=epsort_20260817_050145'; document.head.appendChild(black);
    // GPT Black Gold Atelier 高级黑金增强层(最后加载, 2026-08-17 恢复)
    var gold = document.createElement('link'); gold.rel='stylesheet'; gold.href='/web/vanvy-black-gold.css?v=hero20260817_114320'; document.head.appendChild(gold);

    // 5b. JS 强力钉死纯黑背景(内联样式优先级最高, 盖过 Emby 默认深灰 rgb(30,30,30))
    function applyBlackInline() {
      var BLACK = '#0a0a0c';
      var BLACK2 = '#070709';
      var html = document.documentElement;
      var body = document.body;
      if (html) {
        html.style.backgroundColor = BLACK;
        html.style.color = '#e7e5e4';
      }
      if (body) {
        body.style.backgroundColor = BLACK;
        body.style.color = '#e7e5e4';
      }
      // 背景容器: 深黑渐变(替代默认深灰)
      var bgs = document.querySelectorAll('.backgroundContainer, .backdropContainer');
      for (var i = 0; i < bgs.length; i++) {
        bgs[i].style.background = 'linear-gradient(180deg, ' + BLACK + ' 0%, ' + BLACK2 + ' 100%)';
      }
      log('已强制纯黑背景');
    }
    applyBlackInline();
    // 路由切换时 Emby 可能重建背景容器, 周期性重钉(便宜且幂等)
    setInterval(function () {
      if (document.body && !document.body.vanvyBlackApplied) {
        applyBlackInline();
        try { document.body.vanvyBlackApplied = true; } catch (e) {}
      } else if (document.body) {
        // 背景容器可能被 Emby 重新创建, 保持锁黑
        var bgs = document.querySelectorAll('.backgroundContainer, .backdropContainer');
        for (var i = 0; i < bgs.length; i++) {
          if (bgs[i].style.background && bgs[i].style.background.indexOf('#0a0a0c') !== -1) continue;
          bgs[i].style.background = 'linear-gradient(180deg, #0a0a0c 0%, #070709 100%)';
        }
      }
    }, 2000);

    // 5c. 预载 TMDB 高清宽幅图映射(轮播背景用)
    try {
      fetch('/web/tmdb-backdrops.json', { cache: 'no-store' }).then(function(r){ return r.json(); }).then(function(m){
        window._vanvyTmdbBd = m || {};
        log('已载 TMDB 图映射: ' + Object.keys(m||{}).length + ' 张');
      }).catch(function(){});
    } catch (e) {}

    // 6. 等 ApiClient 就绪后再启动(幂等, 会自己轮询)
    log('Vanvy 资源加载完成, 等待启动');
  }

  // 等待 DOM 就绪后开始
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setup(); });
  } else {
    setup();
  }
})();
