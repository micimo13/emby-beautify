/*!
 * home-banner.js — Emby 首页轮播 (探测过滤版 + 只挂载一次)
 * 探测每个item图片能否加载, 只保留有图且能加载的item -> 保证轮播里全是有图
 * 纯IIFE, 不碰Emby模块系统
 */
(function () {
    'use strict';

    var BANNER_ID = 'emby-home-banner';
    var STYLE_ID = 'emby-home-banner-style';
    var MAX = 8;
    var INTERVAL = 6000;
    var MOUNTED = false;   // 全局只挂一次

    function log() { try { console.log('[home-banner]', [].slice.call(arguments).join(' ')); } catch (e) {} }

    function injectCSS() {
        if (document.getElementById(STYLE_ID)) return;
        var s = document.createElement('style');
        s.id = STYLE_ID;
        s.textContent =
            '#' + BANNER_ID + '{position:relative;width:100%;margin:0 0 1.2em;border-radius:12px;overflow:hidden;background:#0b0e14;box-shadow:0 6px 24px rgba(0,0,0,.5)}' +
            '#' + BANNER_ID + ' .hb-view{position:relative;width:100%;height:300px;overflow:hidden}' +
            '#' + BANNER_ID + ' .hb-slide{position:absolute;inset:0;opacity:0;transition:opacity .6s ease;cursor:pointer;display:flex;align-items:center}' +
            '#' + BANNER_ID + ' .hb-slide.on{opacity:1}' +
            '#' + BANNER_ID + ' .hb-bg{position:absolute;inset:0;background-position:center;background-size:cover;filter:brightness(.6);background-color:#222}' +
'#' + BANNER_ID + ' .hb-bg::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(0,0,0,.55) 0%,rgba(0,0,0,.1) 50%,rgba(0,0,0,.35) 100%);pointer-events:none}' +
            '#' + BANNER_ID + ' .hb-poster{position:relative;z-index:2;flex:0 0 auto;margin-left:3%;width:150px;height:210px;border-radius:8px;overflow:hidden;box-shadow:0 6px 20px rgba(0,0,0,.6)}' +
            '#' + BANNER_ID + ' .hb-poster img{width:100%;height:100%;object-fit:cover}' +
            '#' + BANNER_ID + ' .hb-info{position:relative;z-index:2;margin-left:2.5%;max-width:55%;color:#fff}' +
            '#' + BANNER_ID + ' .hb-title{font-size:30px;font-weight:700;text-shadow:0 2px 10px rgba(0,0,0,.7);margin-bottom:6px}' +
            '#' + BANNER_ID + ' .hb-meta{font-size:14px;color:#bbb;margin-bottom:8px}' +
            '#' + BANNER_ID + ' .hb-overview{font-size:14px;color:#ddd;line-height:1.5;max-height:3.2em;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}' +
            '#' + BANNER_ID + ' .hb-btn{display:inline-block;margin-top:14px;padding:8px 22px;background:#00a4dc;border-radius:20px;font-size:15px;color:#fff;cursor:pointer}' +
            '#' + BANNER_ID + ' .hb-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:3;width:38px;height:38px;background:rgba(0,0,0,.4);color:#fff;font-size:24px;line-height:34px;text-align:center;border-radius:50%;cursor:pointer;user-select:none}' +
            '#' + BANNER_ID + ' .hb-prev{left:12px}' +
            '#' + BANNER_ID + ' .hb-next{right:12px}' +
            '#' + BANNER_ID + ' .hb-dots{position:absolute;bottom:10px;left:0;right:0;z-index:3;text-align:center}' +
            '#' + BANNER_ID + ' .hb-dot{display:inline-block;width:10px;height:10px;margin:0 5px;border-radius:50%;background:rgba(255,255,255,.4);cursor:pointer}' +
            '#' + BANNER_ID + ' .hb-dot.on{background:#fff;transform:scale(1.3)}' +
            '@media(max-width:800px){#' + BANNER_ID + ' .hb-view{height:210px}#' + BANNER_ID + ' .hb-poster{width:100px;height:140px}#' + BANNER_ID + ' .hb-title{font-size:20px}#' + BANNER_ID + ' .hb-info{max-width:60%}}';
        document.head.appendChild(s);
    }

    function apiClient() {
        return window.ApiClient ||
               (window.ConnectionManager && window.ConnectionManager.currentApiClient()) ||
               null;
    }

    function esc(s) {
        return String(s || '').replace(/[&<>"']/g, function (m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
        }).replace(/\n+/g, ' ');
    }

    // 取某item的主图URL(poster用Primary, 背景用Backdrop), 带鉴权
    function imgURL(client, id, type) {
        if (!id || !client) return '';
        try {
            var url = client.getImageUrl(id, { type: type || 'Primary', maxWidth: 1920, quality: 90, tag: '0' });
            try { var tok = client.accessToken(); if (tok) { var sep = (url.indexOf('?') === -1) ? '?' : '&'; url += sep + 'api_key=' + encodeURIComponent(tok); } } catch (e) {}
            return url;
        } catch (e) { return ''; }
    }

    // 探测: 用Image对象测Primary能否加载, 返回 {url, ok} 
    function probe(client, item) {
        return new Promise(function (res) {
            var url = imgURL(client, item.Id, 'Primary');
            if (!url) { res({ ok: false, url: '' }); return; }
            var img = new Image();
            var done = false;
            var t = setTimeout(function () { if (!done) { done = true; res({ ok: false, url: '' }); } }, 8000);
            img.onload = function () { if (!done) { done = true; clearTimeout(t); res({ ok: true, url: url }); } };
            img.onerror = function () { if (!done) { done = true; clearTimeout(t); res({ ok: false, url: '' }); } };
            img.src = url;
        });
    }

    // 探测全部item, 只保留Primary能加载的
    function filterItems(client, items) {
        return Promise.all(items.map(function (it) { return probe(client, it); }))
            .then(function (results) {
                var out = [];
                for (var i = 0; i < results.length; i++) {
                    if (results[i].ok) out.push({ item: items[i], poster: results[i].url });
                    if (out.length >= MAX) break;
                }
                return out;
            });
    }

    function buildAndMount(target) {
        if (MOUNTED) return;
        var client = apiClient();
        if (!client) { setTimeout(buildAndMount, 1500); return; }

        var q = { Limit: 30, IncludeItemTypes: 'Movie,Series', Fields: 'Overview,ProductionYear', EnableImageTypes: 'Primary,Backdrop', ImageTypeLimit: 1 };
        var p;
        try { p = client.getLatestItems(q); } catch (e) { try { p = client.getItems(client.getCurrentUserId(), q); } catch (e2) { return; } }
        if (!p || !p.then) return;

        p.then(function (r) {
            var items = Array.isArray(r) ? r : ((r && r.Items) || []);
            if (!items.length) return;
            if (document.getElementById(BANNER_ID)) { MOUNTED = true; return; }

            filterItems(client, items).then(function (valid) {
                if (!valid.length) return;
                var el = document.createElement('div');
                el.id = BANNER_ID;
                var slides = '', dots = '';
                for (var i = 0; i < valid.length; i++) {
                    var it = valid[i].item;
                    var poster = valid[i].poster;
                    var bgUrl = imgURL(client, it.Id, 'Backdrop');
                    slides += '<div class="hb-slide' + (i === 0 ? ' on' : '') + '" data-id="' + esc(it.Id) + '">'
                        + '<div class="hb-bg"' + (bgUrl ? ' style="background-image:url(\'' + bgUrl + '\')"' : '') + '></div>'
                        + '<div class="hb-poster"><img src="' + poster + '" alt="" onerror="this.parentNode.style.display=\'none\'"></div>'
                        + '<div class="hb-info"><div class="hb-title">' + esc(it.Name) + '</div>'
                        + (it.ProductionYear ? '<div class="hb-meta">' + it.ProductionYear + '</div>' : '')
                        + '<div class="hb-overview">' + esc(it.Overview) + '</div>'
                        + '<div class="hb-btn hb-playbtn" data-id="' + esc(it.Id) + '">&#9654; 播放</div></div></div>';
                    dots += '<span class="hb-dot' + (i === 0 ? ' on' : '') + '" data-i="' + i + '"></span>';
                }
                el.innerHTML = '<div class="hb-view">' + slides
                    + '<div class="hb-arrow hb-prev">&#8249;</div><div class="hb-arrow hb-next">&#8250;</div></div>'
                    + '<div class="hb-dots">' + dots + '</div>';
                target.insertBefore(el, target.firstChild);
                MOUNTED = true;

                // 存 item 对象映射, 供播放按钮用(require playbackManager 直接播放)
                el._itemMap = {};
                for (var mi = 0; mi < valid.length; mi++) {
                    try { el._itemMap[valid[mi].item.Id] = valid[mi].item; } catch (e) {}
                }

                wire(el, valid.length);
                log('轮播已挂载 ' + valid.length + ' 部(均有图)');
            });
        }).catch(function () {});
    }

    function go(banner, d, n) {
        var s = banner.querySelectorAll('.hb-slide');
        var o = banner.querySelectorAll('.hb-dot');
        banner._i = (banner._i + d + n) % n;
        for (var i = 0; i < n; i++) {
            s[i].classList.toggle('on', i === banner._i);
            if (o[i]) o[i].classList.toggle('on', i === banner._i);
        }
    }

    function wire(banner, n) {
        var p = banner.querySelector('.hb-prev'), x = banner.querySelector('.hb-next');
        if (p) p.addEventListener('click', function (e) { e.stopPropagation(); go(banner, -1, n); });
        if (x) x.addEventListener('click', function (e) { e.stopPropagation(); go(banner, 1, n); });
        var dots = banner.querySelectorAll('.hb-dot');
        for (var i = 0; i < dots.length; i++) {
            (function (idx) { dots[idx].addEventListener('click', function (e) { e.stopPropagation(); banner._i = idx; go(banner, 0, n); }); })(i);
        }
        var slides = banner.querySelectorAll('.hb-slide');
        for (var j = 0; j < slides.length; j++) {
            (function (s) { s.addEventListener('click', function () {
                var id = s.getAttribute('data-id');
                if (id) try { window.location.hash = '/item?id=' + id; } catch (e) {}
            }); })(slides[j]);
        }
        // 播放按钮: 跳到 OSD 播放路由直接开播(capture隔离不冲突slide跳详情)
        var playbackBtns = banner.querySelectorAll('.hb-playbtn');
        for (var pb = 0; pb < playbackBtns.length; pb++) {
            (function (btn) { btn.addEventListener('click', function (e) {
                e.stopPropagation();
                e.preventDefault();
                var id = btn.getAttribute('data-id');
                if (!id) return;
                // 用 Emby 的 playbackManager 直接播放(require 拿, hash 路由4.8起播不可靠)
                try {
                    var item = (banner._itemMap && banner._itemMap[id]) || null;
                    if (typeof require === 'function') {
                        require(['playbackManager'], function (pm) {
                            if (!pm) return;
                            if (item) {
                                try { pm.play({ items: [item], fullscreen: true }); } catch (pe) {}
                            } else {
                                // 无item对象则用 connectionManager 取
                                require(['connectionManager'], function (cm) {
                                    var cli = cm.currentApiClient();
                                    try { cli.getItem(cli.getCurrentUserId(), id).then(function (it2) { pm.play({ items: [it2], fullscreen: true }); }); } catch (pe2) {}
                                });
                            }
                        });
                    } else {
                        window.location.hash = '/item?id=' + id;
                    }
                } catch (err2) {
                    window.location.hash = '/item?id=' + id;
                }
            }); })(playbackBtns[pb]);
        }
        banner._i = 0;
        setInterval(function () { if (document.body.contains(banner)) go(banner, 1, n); }, INTERVAL);
    }

    function waitAndBuild() {
        if (MOUNTED) return;
        var target = document.querySelector('.sections')
                  || document.querySelector('.homeSectionsContainer')
                  || document.querySelector('[is="emby-scroller"] .sections');
        if (target && !document.getElementById(BANNER_ID)) {
            buildAndMount(target);
        }
        setTimeout(waitAndBuild, 1500);
    }

    function init() {
        injectCSS();
        setTimeout(waitAndBuild, 2500);
    }


    // ===== 主题切换器 (4色) =====
    function initThemeSwitcher() {
        var KEY='emby-theme';
        var THEMES=[
            {id:'green', css:'green.css',  color:'#0fa573', title:'翡翠绿'},
        ];
        var styleEl=document.getElementById('hb-theme-css');
        if(!styleEl){ styleEl=document.createElement('style'); styleEl.id='hb-theme-css'; document.head.appendChild(styleEl); }

        function loadTheme(id){
            var t=null;
            for(var i=0;i<THEMES.length;i++){ if(THEMES[i].id===id){ t=THEMES[i]; break; } }
            if(!t) return;
            // 动态从服务器拉CSS
            try{
                fetch('/web/themes/'+t.css, {cache:'no-cache'}).then(function(r){ return r.text(); }).then(function(css){
                    styleEl.textContent=css;
                    try{ localStorage.setItem(KEY,id); }catch(e){}
                }).catch(function(){});
            }catch(e){}
        }

        // 启动加载已选主题(默认green)
        var sv='';
        try{ sv=localStorage.getItem(KEY)||''; }catch(e){}
        loadTheme(sv||'green');

        // 切换器UI
        var bar=document.createElement('div');
        bar.style.cssText='position:fixed;top:64px;right:16px;z-index:100000;display:flex;gap:8px;align-items:center;padding:7px 10px;background:rgba(0,0,0,.7);border-radius:20px;backdrop-filter:blur(6px);box-shadow:0 2px 12px rgba(0,0,0,.5)';
        var lbl=document.createElement('span');
        lbl.textContent='主题';
        lbl.style.cssText='color:#ccc;font-size:12px;margin-right:2px;';
        bar.appendChild(lbl);
        THEMES.forEach(function(t){
            var d=document.createElement('button');
            d.title=t.title;
            d.style.cssText='width:20px;height:20px;border-radius:50%;border:2px solid rgba(255,255,255,.7);background:'+t.color+';cursor:pointer;padding:0;transition:transform .15s';
            d.addEventListener('click',function(ev){ ev.stopPropagation(); loadTheme(t.id); drawActive(); });
            d._tid=t.id;
            bar.appendChild(d);
        });
        function drawActive(){
            var cur=''; try{ cur=localStorage.getItem(KEY)||''; }catch(e){}
            var bs=bar.querySelectorAll('button');
            for(var i=0;i<bs.length;i++){ bs[i].style.borderColor = (bs[i]._tid===cur)?'#fff':'rgba(255,255,255,.5)'; bs[i].style.transform = (bs[i]._tid===cur)?'scale(1.3)':'scale(1)'; }
        }
        document.body.appendChild(bar);
        drawActive();
        // 兼容Emby路由body变化: 轮询保bar在body
        setInterval(function(){ if(!document.body.contains(bar)){ if(document.body) document.body.appendChild(bar); } }, 3000);
    }
    setTimeout(initThemeSwitcher, 5000);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
