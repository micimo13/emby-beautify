// Vanvy theme activate
document.documentElement.classList.add('vanvy-theme-glass_graphite');
