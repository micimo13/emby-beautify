# Emby 黑金影院首页美化 (Vanvy Black Gold Atelier)

给 Emby 4.8.x 加一套高档"黑金影院"首页：影院横幅轮播 + 黑曜石毛玻璃 + 媒体库高级封面 + 隶书镂空字。

## 功能亮点
- 🎬 **影院横幅轮播**：21:9 黑金横幅，最新上映+评分权衡选片，电影/剧集均衡，左右箭头固定居中
- 🎞️ **剧集快捷播放**：横幅切到剧集时底部显示分季+单集横排，点击直接播放
- 🖼️ **媒体库高级封面卡**：每张卡用真实影片宽幅剧照(Backdrop)做封面，黑曜石卡+香槟金描边+悬浮微光
- ✍️ **隶书镂空白线字**：媒体库分类名/标题用书法隶书(STLiti/LiSu)+白色镂空描边，东方奢品气质
- 🔲 **纯黑高质感**：黑曜石多层背景 + 毛玻璃导航/卡片 + 金色细线点缀
- 🌐 **全端适配**：移动端防性能/bling、reduced-motion 支持

## 目录结构
```
emby-meihua/
├── install.sh                 # 一键安装脚本(部署到Emby容器)
├── emby-web-banner/           # 美化文件(部署内容)
│   ├── vanvy/                 # Vanvy 皮肤(横幅/轮播/剧集/媒体库/主题)
│   ├── vanvy-setup.js         # 统一加载器(依序加载皮肤+增强层)
│   ├── vanvy-black.css        # 纯黑高质感覆盖层
│   ├── vanvy-black-gold.css   # Black Gold 增强层(黑曜石/隶书字/媒体库卡)
│   ├── tmdb-backdrops.json    # TMDB 高清宽幅图映射(轮播/封面用)
│   └── home-banner.js         # 旧版横幅(可留存)
└── README.md
```

## 安装(一键)
在**有 docker 能访问 Emby 容器**的机器上(通常是 NAS 宿主):
```bash
chmod +x install.sh
./install.sh                  # 容器名默认 emby
./install.sh --container emby # 或指定容器名
```
脚本会:
1. 备份原文件到容器 `/system/dashboard-ui/.meihua_backup_<时间戳>` (可回滚)
2. 部署美化文件进容器
3. 确保 index.html 已引入 `vanvy-setup.js`
4. 提示完成

装完 **Emby 首页 Ctrl+F5 强刷** 看效果。

## 回滚
```bash
# 用脚本备份还原(if needed 手动):
docker exec emby mv /system/dashboard-ui/.meihua_backup_xxx/index.html /system/dashboard-ui/index.html
docker exec emby rm -rf /system/dashboard-ui/vanvy
# 或直接删整个备份目录(彻底还原默认):
docker exec emby rm -rf /system/dashboard-ui/vanvy /system/dashboard-ui/vanvy-setup.js /system/dashboard-ui/vanvy-black*.css
```

## 备注
- 依赖: Emby 4.8.11(web根 /system/dashboard-ui/), 容器内可写该目录
- npm不需要, 纯静态JS/CSS注入, 无后端改动
- `tmdb-backdrops.json` 由配套 cron 生成(update_tmdb_bd.py), 缺失时轮播自动回退影片图
