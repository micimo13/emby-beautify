#!/usr/bin/env bash
# ============================================================
# Emby 黑金影院首页美化 - 一键安装脚本
# 适用: Emby 4.8.x (web 根 /system/dashboard-ui/)
# 作用: 部署 Vanvy 黑金影院横幅 + Black Gold 增强层(轮播/媒体库/隶书镂空字)
# 用法:
#   ./install.sh                      # 容器名默认 emby
#   ./install.sh -c moviepilot || true  # 指定容器名
#   ./install.sh --container emby
# 说明: 自动备份原文件到时间戳目录, 可一键回滚; 幂等(已装则刷新bump版本)
# ============================================================
set -euo pipefail

CONTAINER="emby"
WEBROOT="/system/dashboard-ui"
PKGDIR="$(cd "$(dirname "$0")" && pwd)/emby-web-banner"
STAMP="$(date +%Y%m%d_%H%M%S)"

usage(){ echo "用法: $0 [-c|--container 容器名]"; exit 1; }
while [[ $# -gt 0 ]]; do
  case "$1" in
    -c|--container) CONTAINER="$2"; shift 2;;
    -h|--help) usage;;
    *) echo "未知参数: $1"; usage;;
  esac
done

echo "=============================================="
echo " Emby 黑金影院美化 - 一键安装"
echo " 容器: $CONTAINER   目标: $WEBROOT"
echo "=============================================="

# 0. 前置: docker 可用 + 容器存在
if ! docker ps --format '{{.Names}}' | grep -qx "$CONTAINER"; then
  echo "❌ 容器 [$CONTAINER] 不存在或未运行, 请确认 (docker ps 查看)"
  exit 1
fi
if ! docker exec "$CONTAINER" ls "$WEBROOT/index.html" >/dev/null 2>&1; then
  echo "❌ 容器内 $WEBROOT/index.html 不存在, web 根路径可能不同"
  exit 1
fi

# 1. 备份现有(可回滚)
BACKUP="${WEBROOT}/.meihua_backup_${STAMP}"
echo "== [1/4] 备份原文件到容器 $BACKUP (可回滚) =="
docker exec "$CONTAINER" mkdir -p "$BACKUP"
for src in index.html vanvy vanvy-setup.js vanvy-black.css vanvy-black-gold.css tmdb-backdrops.json home-banner.js; do
  docker exec "$CONTAINER" sh -c "test -e $WEBROOT/$src && cp -r $WEBROOT/$src $BACKUP/ || true"
done
echo "   已备份 → $BACKUP"

# 2. 部署文件到容器
echo "== [2/4] 部署美化文件 =="
docker cp "$PKGDIR/vanvy"            "$CONTAINER:$WEBROOT/vanvy"         2>/dev/null
docker cp "$PKGDIR/vanvy-setup.js"   "$CONTAINER:$WEBROOT/vanvy-setup.js" 2>/dev/null
docker cp "$PKGDIR/vanvy-black.css"  "$CONTAINER:$WEBROOT/vanvy-black.css" 2>/dev/null
docker cp "$PKGDIR/vanvy-black-gold.css" "$CONTAINER:$WEBROOT/vanvy-black-gold.css" 2>/dev/null
docker cp "$PKGDIR/tmdb-backdrops.json" "$CONTAINER:$WEBROOT/tmdb-backdrops.json" 2>/dev/null || true
docker cp "$PKGDIR/home-banner.js"   "$CONTAINER:$WEBROOT/home-banner.js" 2>/dev/null || true

# 3. 确保 index.html 引入 vanvy-setup.js
echo "== [3/4] 检查 index.html 加载器引用 =="
if docker exec "$CONTAINER" grep -q 'vanvy-setup.js' "$WEBROOT/index.html" 2>/dev/null; then
  echo "   已引用 vanvy-setup.js ✅"
elif docker exec "$CONTAINER" sh -c "command -v sed >/dev/null && echo sed_ok" | grep -q sed_ok; then
  # 在 </body> 前注入(若 container 有 sed)
  docker exec "$CONTAINER" sh -c "sed -i 's#</body>#    <script src=\"vanvy-setup.js\" defer></script>\\n</body>#' $WEBROOT/index.html" 2>/dev/null \
    && echo "   已注入 vanvy-setup.js ✅" || echo "   ⚠️ 无法自动注入, 请手动在 </body> 前加 <script src=\"vanvy-setup.js\" defer>"
else
  echo "   ⚠️ 容器无 sed, 请手动在 index.html </body> 前加加载器"
fi

# 4. 完成提示
echo "== [4/4] 完成 =="
echo "=============================================="
echo " ✅ 美化已部署到容器 [$CONTAINER]"
echo "    刷新 Emby 首页(Ctrl+F5)查看效果"
echo "    回滚: docker exec $CONTAINER mv $BACKUP/index.html $WEBROOT/index.html"
echo "          或 docker exec $CONTAINER rm -rf $WEBROOT/vanvy 恢复默认"
echo "=============================================="
