#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit · 在线安装入口
#  直接从 GitHub 仓库拉取最新代码构建美化
#  用法:
#    curl -sL https://raw.githubusercontent.com/micimo13/vanvy-emby-kit/main/scripts/online-install.sh | bash
# =============================================================================

set -e

# GitHub 仓库地址
REPO_OWNER="micimo13"
REPO_NAME="vanvy-emby-kit"
REPO_BRANCH="main"
REPO_BASE="https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/${REPO_BRANCH}"

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   🎨 Vanvy Emby Kit · 在线安装器                        ║"
echo "  ║   Make your Emby beautiful                              ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""

# 需要 docker
command -v docker >/dev/null 2>&1 || { echo "❌ 未检测到 docker"; exit 1; }

# 下载项目
TMPDIR=$(mktemp -d)
echo "⬇  从 GitHub 下载 Vanvy Emby Kit ..."
if ! curl -fsSL --connect-timeout 15 --max-time 120 "${REPO_BASE}/emby-kit.tar.gz" -o "$TMPDIR/kit.tar.gz" 2>/dev/null \
   && ! curl -fsSL --connect-timeout 15 --max-time 120 "https://codeload.github.com/${REPO_OWNER}/${REPO_NAME}/tar.gz/refs/heads/${REPO_BRANCH}" -o "$TMPDIR/kit.tar.gz" 2>/dev/null; then
  echo "❌ 下载失败, 请检查网络"
  rm -rf "$TMPDIR"
  exit 1
fi
tar xzf "$TMPDIR/kit.tar.gz" -C "$TMPDIR" 2>/dev/null
SRC=$(find "$TMPDIR" -maxdepth 1 -type d -name "${REPO_NAME}*" | head -1)
[ -z "$SRC" ] && SRC="$TMPDIR"

echo "✅ 下载完成, 启动安装向导..."
echo ""
cd "$SRC"
bash install.sh "$@"
RC=$?

rm -rf "$TMPDIR"
exit $RC
