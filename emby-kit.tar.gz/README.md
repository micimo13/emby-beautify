<p align="center">
  <img src="docs/screenshot-home-800.png" alt="Vanvy Emby Kit 首页效果" width="800"/>
</p>

<h1 align="center">🎨 Vanvy Emby Kit</h1>

<p align="center">
  <b>Emby 美化智能引擎</b> — 一键体检镜像 · 风格化轮播 · 主题美化 · 功能增强 · 重建不丢
</p>

<p align="center">
  <a href="https://github.com/micimo13/vanvy-emby-kit/stargazers"><img src="https://img.shields.io/github/stars/micimo13/vanvy-emby-kit" alt="Stars"/></a>
  <a href="https://github.com/micimo13/vanvy-emby-kit/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue" alt="License"/></a>
  <a href="https://github.com/micimo13/vanvy-emby-kit/releases"><img src="https://img.shields.io/badge/version-v1.0-green" alt="Version"/></a>
</p>

---

## 📖 项目简介

**Vanvy Emby Kit** 是一个针对 **Emby 媒体服务器**（官方版 / 开心版 / LinuxServer 版）的美化全家桶。

它像一位**智能管家**：先体检你的 Emby 镜像，识别版本与内置"坑"，再给你**可落地、互不冲突**的美化方案。前端复用成熟开源项目设计，脚本负责智能部署、去重注入、持久化恢复——**容器怎么重建，美化都不丢**。

> 💡 本工具诞生于真实需求：开心版镜像（amilys 等）内置旧版 emby-crx + 启动钩子重置配置，导致"装一次丢一次"。我们通过**镜像体检 + 持久化钩子接管**彻底解决了这个问题。

---

## ✨ 功能特性

### 🧬 智能镜像体检

安装前自动识别你的 Emby 环境：

```
  ┌────────────────────────────────────────────────────────────┐
  │  🧬 镜像体检报告                                          │
  ├────────────────────────────────────────────────────────────┤
  │  📦 容器       emby-18                                     │
  │  🖼️  镜像       amilys/embyserver:4.8.11.0                 │
  │  📊 Emby 版本  4.8.11.0                                    │
  ├────────────────────────────────────────────────────────────┤
  │  🔍 镜像类型: 开心版 (amilys)                              │
  │  🔧 内置美化:  旧版 emby-crx (需覆盖为官方版) + 内置弹幕     │
  │  ⚙️  启动钩子: 存在 (ext.sh)                                │
  └────────────────────────────────────────────────────────────┘
```

自动识别并绕开开心版镜像的"旧版 emby-crx + 启动钩子重置"机制。

### 🎠 轮播三风格（互斥三选一）

| 风格 | 效果 | 适用版本 |
|---|---|---|
| **🎠 经典轮播** | 满屏 Backdrop 大图 + 标题 + 简介 + LOGO，8 秒自动滚动 | 4.8 |
| **🎠 Fluent 轮播** | 无缝循环 + 左右导航 + 失败自动清理 | 4.8 / 4.9 |
| **🎠 Banner 轮播** | Banner 横幅图 + 随机排序 + 按钮控制 | 4.8 / 4.9 |

### 🎨 主题美化（毛玻璃互斥，可叠加品牌主题）

| 主题 | 效果 |
|---|---|
| 🍇 石墨黑毛玻璃 | 深色毛玻璃质感 |
| 🔵 冰川蓝毛玻璃 | 冷色调毛玻璃 |
| 🟣 极光紫毛玻璃 | 紫色系毛玻璃 |
| 🟢 翡翠绿毛玻璃 | 绿色系毛玻璃 |
| 🩷 樱花粉毛玻璃 | 粉色系毛玻璃 |
| 🟠 琥珀金毛玻璃 | 暖色系毛玻璃 |
| 👑 **vanvy_custom** | VANVY 品牌美化：LOGO 替换 / 椭圆标签 / 简介弹框 / 剧集列表 / 播放页 |

### ⚡ 功能增强（8 个，互不重叠）

| 组件 | 功能 |
|---|---|
| 💬 **弹幕** | 多源弹幕（B站 / 抖音等） |
| ⭐ **豆瓣评分** | 豆瓣 / Bangumi 评分展示 |
| 🖼️ **剧照展示** | 详情页高清剧照 + Swiper 浏览 |
| ⏩ **播放倍速** | 快捷键调节播放速度 |
| 🎬 **外部播放器** | PotPlayer / VLC / MPV / IINA 等 10 种 |
| 🔗 **远程路径** | 显示远程资源路径并可复制 |
| 🔞 **JAV 详情** | Javdb 刮削 / 番号识别 / 翻译 / 预告片 |
| 🎞️ **播放页增强** | OSD 布局 / 音量条适配 |

### 💾 持久化 & 卸载

- **容器重建不丢**：ext.sh 钩子全量恢复（文件 + 注入快照 + 自动清理镜像旧版）
- **`uninstall.sh`**：`--all` 全卸 / `--only` 单卸 / `--reset` 完全还原

---

## 🚀 快速开始

### 在线安装（一条命令，从 GitHub 构建）

```bash
curl -sL https://raw.githubusercontent.com/micimo13/vanvy-emby-kit/main/scripts/online-install.sh | bash
```

### 交互式安装

```bash
bash install.sh
```

自动流程：
1. 🔍 识别容器（多个自动列出）
2. 🧬 镜像体检报告
3. 🎠 选择轮播风格（按版本自动推荐）
4. 🎨 选择主题（毛玻璃互斥单选）
5. ⚡ 选择功能组件（多选）
6. ✅ 确认安装 → 自动清理旧版 → 注入 → 持久化

### 组件包快捷安装

```bash
# 📦 极简包: 经典轮播 + vanvy_custom + 品牌
bash install.sh --container emby-18 --package minimal --yes

# 📦 观影包: Fluent + 弹幕/豆瓣/剧照/倍速/播放器
bash install.sh --container emby-18 --package movie --yes

# 🎯 指定组件
bash install.sh --container emby-18 --feature "banner_classic,vanvy_custom,danmaku,douban" --yes

# 🔍 只体检
bash install.sh --container emby-18 --detect-only
```

### 卸载 / 还原

```bash
bash uninstall.sh --container emby-18 --all          # 卸载全部(含持久化)
bash uninstall.sh --container emby-18 --only danmaku # 卸载单个组件
bash uninstall.sh --container emby-18 --reset        # 完全还原出厂
```

---

## 🏗️ 架构设计

```
emby-kit/
├── install.sh              # 主安装器（交互 + CLI）
├── uninstall.sh            # 卸载/还原（--all/--only/--reset）
├── lib/
│   ├── detect.sh           # 🧬 镜像体检引擎
│   ├── manifest.sh         # 📦 组件注册表（声明式）
│   ├── common.sh           # 🔧 注入/去重/备份工具
│   └── persist.sh          # 💾 持久化引擎（ext.sh 钩子）
├── core/                   # 核心库（vanvy-core.js + jquery/md5）
├── components/
│   ├── home/               # 🎠 轮播（三选一互斥）
│   ├── themes/             # 🎨 主题（毛玻璃6色 + 品牌 + 暗色）
│   ├── features/           # ⚡ 功能组件（8个）
│   └── branding/           # 🏷️ 品牌注入
└── scripts/
    └── online-install.sh   # 🚀 在线安装入口（GitHub 源）
```

### 设计原则

1. **一个区域只归一个组件** —— 按"页面区域"划分，互不重叠
2. **毛玻璃互斥** —— 6 色单选，品牌/暗色可叠加
3. **去重注入** —— 共享依赖（jquery/md5/common-utils）只注入一次
4. **失败保护** —— Fluent 图片加载失败不循环重试（防闪烁）
5. **持久化全量** —— 文件 + 注入快照 + 清理镜像旧版，recreate 完整恢复

---

## 📸 效果展示

<p align="center">
  <img src="docs/screenshot-home-800.png" alt="首页轮播效果" width="700"/>
  <br/>
  <em>经典轮播：满屏大图 + 标题 + 简介 + MORE 按钮</em>
</p>

---

## 🧪 验证记录（emby-18 R18 真机）

| 验证项 | 结果 |
|---|---|
| 经典轮播 10 图全加载 | ✅ 无闪烁 |
| Fluent 失败保护 | ✅ 不循环重试 |
| 全功能组件共存 | ✅ 无冲突无错误 |
| 卸载彻底性 | ✅ 注入/目录/持久卷全清 |
| **容器重建持久化** | ✅ 完整恢复（含清理镜像旧版） |
| 菜单编号一致性 | ✅ 显示 = 取值 |

---

## 🙏 致谢

本项目的美化设计与前端代码，参考并整合了以下优秀的开源项目与作者的作品，在此表示衷心感谢：

| 项目 / 作者 | 贡献 |
|---|---|
| [Nolovenodie/emby-crx](https://github.com/Nolovenodie/emby-crx) | 经典轮播设计（满屏 Backdrop + 信息层 + LOGO） |
| [heichaowo/Emby-Fluent](https://github.com/heichaowo/Emby-Fluent) | Fluent 轮播与毛玻璃设计（无缝滚动 / 失败清理） |
| [chen3861229/dd-danmaku](https://github.com/chen3861229/dd-danmaku) | 弹幕组件 |
| [kjtsune/embyToLocalPlayer](https://github.com/kjtsune/embyToLocalPlayer) | 豆瓣评分与外部播放器方案 |
| [XingyiHua2024/Emby-Javascript-Details](https://github.com/XingyiHua2024/Emby-Javascript-Details) | JAV 详情页（Javdb / 番号 / 翻译） |
| [v1rusnl/Embymalism](https://github.com/v1rusnl/Embymalism) | 极简主题设计参考 |
| **MICIMO（群晖资产）** | BannerCarousel / 播放页增强 / 远程路径等自研脚本 |

> 部分组件为开源项目原版整合，版权归原作者所有；本项目负责部署与集成。若涉及版权问题请联系我们调整。

---

## 📄 License

[MIT](LICENSE)

---

<p align="center">
  <b>Vanvy Emby Kit</b> · Make your Emby beautiful 🎨
</p>
