# 🎨 Vanvy Emby Kit · 工程审查与重构规划

> 角色：工程师 · 编制：虾子🦐 · 2026-08-11
> 目的：彻底消除组件重叠/冲突，R18(emby-18) 逐一验证后发布 GitHub

---

## 一、组件重叠审计结果（实锤）

| 组件 | 真实身份 | 与谁重叠 | 结论 |
|---|---|---|---|
| **detail_enhance** | 自研详情增强(2.4KB) | vanvy_custom 主题含同款 CSS | ⚠️ 合并进 vanvy_custom |
| **list_enhance** | **群晖 Stagephoto 剧照库(225KB, 含swiper+viewer)** | **extrafanart(剧照) 100%重叠** + banner_carousel(swiper) | 🔴 与 extrafanart 合并 |
| **player_enhance** | 群晖 tx.js(4KB, 播放页) | vanvy_custom 含播放页 CSS | ⚠️ 保留(tx.js 是 JS 逻辑) |
| **ui_clean** | 自研 CSS(315B) | vanvy_custom 含隐藏冗余 CSS | ⚠️ 合并进 vanvy_custom |
| **extrafanart** | 群晖 jz-1.js(剧照 7.6KB) | list_enhance(Stagephoto) 重叠 | 🔴 合并 |
| **embytool** | 群晖 EmbyTool.js(远程路径) | 无（唯一功能） | ✅ 保留 |
| **fluent_glass 主题** | Emby-Fluent 整包 CSS 残留 | banner_fluent 轮播自带 | 🔴 删除 |
| **banner_carousel** | 群晖 BannerCarousel.js | list_enhance 内 swiper | ⚠️ 保留(独立轮播) |

**核心结论**：
1. **list_enhance 和 extrafanart 是同一功能（剧照展示）的两个版本** → 必须合并
2. **vanvy_custom 主题已覆盖 detail_enhance + ui_clean 的功能** → 合并
3. **fluent_glass 是未注册残留** → 删除

---

## 二、重构方案（一个区域只归一个组件）

### 2.1 合并决策

| 操作 | 组件 | 结果 |
|---|---|---|
| **合并** | list_enhance + extrafanart → `extrafanart` | 剧照展示统一用 Stagephoto 库(225KB 功能全) |
| **合并** | detail_enhance + ui_clean → 进 `vanvy_custom` 主题 | 详情美化统一由主题管 |
| **删除** | fluent_glass 残留目录 | 清掉 |
| **保留** | danmaku/douban/playbackrate/localplayer/embytool/jav_details | 功能唯一 |
| **保留** | banner_classic/banner_fluent/banner_carousel | 轮播三选一 |
| **保留** | glass_* 毛玻璃 6 色 + vanvy_custom | 主题 |
| **新增互斥** | 毛玻璃主题单选 | 防多色变量覆盖 |

### 2.2 重构后组件清单

```
emby-kit/
├── install.sh / uninstall.sh / README.md
├── scripts/online-install.sh (→ 改 GitHub 源)
├── lib/ (common/detect/manifest/persist.sh)
├── core/ (vanvy-core.js + jquery/md5/common-utils)
├── components/
│   ├── home/ (轮播, 互斥三选一)
│   │   ├── banner_classic/  banner_fluent/  banner_carousel/
│   ├── themes/ (主题)
│   │   ├── vanvy_custom/  (详情/播放/列表/界面 总美化)
│   │   ├── glass_graphite|blue|purple|emerald|pink|amber/ (毛玻璃, 单选)
│   ├── features/ (功能, 唯一)
│   │   ├── danmaku/  douban/  extrafanart/(合并后)  playbackrate/
│   │   ├── localplayer/  embytool/  jav_details/
│   └── branding/
```

---

## 三、验证计划（R18 emby-18 逐一测）

| # | 场景 | 验证点 |
|---|---|---|
| V1 | 经典轮播 + vanvy_custom | 满屏轮播 + 详情美化，无错误 |
| V2 | Fluent 轮播 + vanvy_custom | 无缝轮播（含失败保护），无闪烁 |
| V3 | Banner图轮播 + vanvy_custom | 横幅图轮播 |
| V4 | 毛玻璃 6 色逐一 + 经典轮播 | 单选生效，无变量冲突 |
| V5 | 全功能组件 + 经典轮播 | 弹幕/豆瓣/剧照/倍速/播放器/远程路径/JAV 全加载 |
| V6 | 卸载/重装 | --all 干净，重装无残留 |
| V7 | 持久化 | recreate 后自动恢复 |
| V8 | 编号选择 | 显示=取值，无误装 |

全部通过 → 建 GitHub 仓库 → online-install.sh 改 GitHub 源 → 图文 README

---

## 四、GitHub 发布计划

1. 建私有仓库 `vanvy-emby-kit`（或主人命名）
2. 推送重构后代码
3. `scripts/online-install.sh` 改为从 GitHub raw 拉取
4. README 图文并茂（架构图/效果图/安装教程/组件清单）
5. 主人确认后公开
