#!/usr/bin/env bash
# =============================================================================
#  Emby 美化引擎 · 公共函数库
# =============================================================================

C_INFO='\033[1;36m'; C_OK='\033[1;32m'; C_WARN='\033[1;33m'
C_ERR='\033[1;31m'; C_ASK='\033[1;35m'; C_OFF='\033[0m'

c_info()  { printf "${C_INFO}[信息]${C_OFF} %s\n" "$*"; }
c_ok()    { printf "${C_OK}[成功]${C_OFF} %s\n" "$*"; }
c_warn()  { printf "${C_WARN}[警告]${C_OFF} %s\n" "$*"; }
c_err()   { printf "${C_ERR}[错误]${C_OFF} %s\n" "$*"; }
c_ask()   { printf "${C_ASK}[询问]${C_OFF} %s" "$*"; }

die() { c_err "$*"; exit 1; }

# 安全读取输入 (终端/管道 自适应, /dev/tty 失败静默)
safe_read() {
  local var="$1" default="${2:-}" val=""
  if [ -t 0 ]; then
    read -r val
  elif [ -e /dev/tty ]; then
    read -r val < /dev/tty 2>/dev/null || read -r val
  else
    read -r val
  fi
  [ -z "$val" ] && val="$default"
  eval "$var=\"$val\""
}

# 确认 (默认N, 支持管道输入)
confirm() {
  c_ask "$1 [y/N]: "
  local ans=""
  if [ -t 0 ]; then
    read -r ans
  elif [ -e /dev/tty ]; then
    read -r ans < /dev/tty
  else
    # 无 tty: 尝试从 stdin 读 (管道场景)
    read -r ans
  fi
  [ "$ans" = "y" ] || [ "$ans" = "Y" ]
}

# 备份 index.html (每次注入前)
backup_index() {
  docker exec "$CONTAINER" sh -c "
    mkdir -p /config/backups/emby-beautify
    cp '$DASHBOARD_DIR/index.html' \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\"
  " 2>/dev/null && c_ok "✓ index.html 已备份"
}

# 幂等注入: 把注入行插入 </head> 前 (marker 已存在则跳过)
inject_to_index() {
  local marker="$1" inject_file="$2" index_file="$3"
  # 逐行检查已存在 (防重复), 过滤出真正需要注入的行
  local filtered="/tmp/vanvy-filtered.html"
  : > "$filtered"
  local total=0 exist=0 line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    total=$((total+1))
    if docker exec "$CONTAINER" sh -c "grep -qF -- '${line}' '$index_file'" 2>/dev/null; then
      exist=$((exist+1))
    else
      printf '%s\n' "$line" >> "$filtered"
    fi
  done < "$inject_file"

  if [ "$total" -gt 0 ] && [ "$exist" -eq "$total" ]; then
    echo "    [已存在] $marker 相关注入已存在, 跳过"
    rm -f "$filtered"
    return 0
  fi
  if [ ! -s "$filtered" ]; then
    echo "    [已存在] 所有注入行已存在, 跳过"
    rm -f "$filtered"
    return 0
  fi

  # 上传过滤后的注入文件
  docker cp "$filtered" "$CONTAINER:/tmp/vanvy-inject-final.html" 2>/dev/null
  docker exec -i "$CONTAINER" sh -c "
    set -e
    INDEX='$index_file'
    if [ ! -s /tmp/vanvy-inject-final.html ]; then
      echo '[错误] 注入文件为空, 已中止'
      exit 1
    fi
    mkdir -p /config/backups/emby-beautify
    cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\" || exit 1
    if grep -q '</head>' \"\$INDEX\"; then
      ANCHOR='</head>'
    else
      ANCHOR='<body'
    fi
    awk -v anchor=\"\$ANCHOR\" 'FNR==NR { lines[NR]=\$0; n=NR; next } index(\$0, anchor)==1 && !injected { for (i=1; i<=n; i++) print lines[i]; injected=1 } { print }' \\
      /tmp/vanvy-inject-final.html \"\$INDEX\" > \"\$INDEX.new\"
    rm -f /tmp/vanvy-inject-final.html
    if [ -s \"\$INDEX.new\" ]; then
      mv \"\$INDEX.new\" \"\$INDEX\"
      echo \"[注入] $marker 完成\"
    else
      rm -f \"\$INDEX.new\"
      echo '注入失败: 新文件为空, 已保留原文件'
      exit 1
    fi
  " 2>&1 | sed 's/^/    /'
  rm -f "$filtered"
}

# 拷贝资源到容器
push_assets() {
  local src_dir="$1" dst_dir="$2"
  docker exec "$CONTAINER" sh -c "mkdir -p '$dst_dir'" 2>/dev/null
  for f in "$src_dir"/*; do
    [ -f "$f" ] || continue
    local fname
    fname="$(basename "$f")"
    docker cp "$f" "$CONTAINER:$dst_dir/$fname" 2>/dev/null || { c_err "复制失败: $fname"; return 1; }
    echo "    ✓ 复制 $fname"
  done
}

# 检查组件是否已注入
is_installed() {
  local marker="$1"
  [ -n "$marker" ] || return 1
  docker exec "$CONTAINER" sh -c "grep -qF '$marker' '$DASHBOARD_DIR/index.html'" 2>/dev/null
}

# 官方版检测: 首页美化是否官方版 (区分镜像自带旧版)
# 返回: 0=官方版 1=未装 2=旧版残留
is_banner_official() {
  local id="$1" dir="vanvy/banner_$id" mainjs
  if ! is_installed "vanvy/banner_$id/banner-$id.js"; then
    # 检查是否旧版 emby-crx 残留
    if docker exec "$CONTAINER" sh -c "grep -q 'emby-crx/main.js' '$DASHBOARD_DIR/index.html'" 2>/dev/null; then
      return 2
    fi
    return 1
  fi
  return 0
}

# 清理旧版 emby-crx 残留 (开心版镜像)
cleanup_builtin_crx() {
  if [ "$BUILTIN_CRX" = "1" ]; then
    c_warn "清理镜像内置旧版 emby-crx..."
    # 移除 index.html 中的 emby-crx 注入行
    docker exec "$CONTAINER" sh -c "
      INDEX='$DASHBOARD_DIR/index.html'
      cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.pre-clean.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
      sed -i '/emby-crx\/style.css/d; /emby-crx\/common-utils.js/d; /emby-crx\/jquery/d; /emby-crx\/md5/d; /emby-crx\/config.js/d; /emby-crx\/main.js/d' \"\$INDEX\"
      # 保留目录(避免破坏), 但删旧版 main.js 防止误加载
      rm -f /system/dashboard-ui/emby-crx/main.js /system/dashboard-ui/emby-crx/config.js
      echo '  旧版 emby-crx 注入已清理'
    " 2>&1 | sed 's/^/    /'
    BUILTIN_CRX=0
    c_ok "✓ 旧版 emby-crx 已清理"
  fi
}
