#!/usr/bin/env bash
# =============================================================================
#  Emby 美化引擎 · 持久化引擎 (persist)
#  ---------------------------------------------------------------------------
#  解决: 开心版镜像内置旧版 + 容器 recreate 丢可写层修改
#  方案: 官方文件存 /config/vanvy-official/ + ext.sh 钩子每次启动自动部署
# =============================================================================

# 把核心文件存入持久卷
persist_assets() {
  local persist_dir="/config/vanvy-official"
  docker exec "$CONTAINER" sh -c "mkdir -p '$persist_dir'" 2>/dev/null
  # 持久化 core 库
  for f in "$SCRIPT_DIR/core/"*.js "$SCRIPT_DIR/core/"*.css; do
    [ -f "$f" ] || continue
    docker cp "$f" "$CONTAINER:$persist_dir/$(basename "$f")" 2>/dev/null
  done
  # 持久化 JAV config.json
  if [ -f "$SCRIPT_DIR/components/features/jav_details/config.json" ]; then
    docker cp "$SCRIPT_DIR/components/features/jav_details/config.json" "$CONTAINER:$persist_dir/config.json" 2>/dev/null
  fi
  # 持久化 index.html 注入行快照 (供 recreate 后恢复)
  docker exec "$CONTAINER" sh -c "
    grep 'vanvy/' '$DASHBOARD_DIR/index.html' > '$persist_dir/injections.txt' 2>/dev/null
    echo '注入行快照: \$(wc -l < '$persist_dir/injections.txt') 行'
  " 2>&1 | sed 's/^/    /'
  # 持久化整个 vanvy 目录 (recreate 后文件全丢, 需整体备份)
  docker exec "$CONTAINER" sh -c "
    rm -rf '$persist_dir/vanvy'
    cp -r '$DASHBOARD_DIR/vanvy' '$persist_dir/vanvy' 2>/dev/null
    echo 'vanvy 全量备份: \$(find '$persist_dir/vanvy' -type f | wc -l) 文件'
  " 2>&1 | sed 's/^/    /'
  c_ok "✓ 核心库已持久化 → /config/vanvy-official/"
}

# 写入 ext.sh 持久化钩子 (幂等)
persist_write_hook() {
  local ext_file="/config/config/ext.sh"
  local marker="vanvy-beautify-persist"
  docker exec "$CONTAINER" sh -c "mkdir -p /config/config 2>/dev/null; [ -f '$ext_file' ] || { echo '#!/bin/sh' > '$ext_file'; chmod +x '$ext_file'; }"
  if docker exec "$CONTAINER" sh -c "grep -q '$marker' '$ext_file'" 2>/dev/null; then
    c_ok "✓ ext.sh 钩子已存在, 跳过"
    return 0
  fi
  # 备份原 ext.sh
  docker exec "$CONTAINER" sh -c "cp '$ext_file' '$ext_file.bak.\$(date +%Y%m%d-%H%M%S)' 2>/dev/null"
  # 生成钩子文件
  local hook="/tmp/vanvy-persist-hook.sh"
  cat > "$hook" << 'EOF'
#!/bin/sh
# ==== vanvy-beautify 持久化部署 ====
VANVY_DIR='/config/vanvy-official'
INDEX='/system/dashboard-ui/index.html'
CRX='/system/dashboard-ui/emby-crx'
if [ -d "$VANVY_DIR" ]; then
  # 1. 整体恢复 vanvy 目录 (recreate 后文件全丢, 从全量备份还原)
  if [ -d "$VANVY_DIR/vanvy" ]; then
    rm -rf /system/dashboard-ui/vanvy
    cp -r "$VANVY_DIR/vanvy" /system/dashboard-ui/vanvy 2>/dev/null
    echo "  ✓ vanvy 全量恢复: $(find /system/dashboard-ui/vanvy -type f | wc -l) 文件"
  else
    # 兼容旧版: 只恢复 core
    mkdir -p /system/dashboard-ui/vanvy/core 2>/dev/null
    for f in "$VANVY_DIR"/*.js "$VANVY_DIR"/*.css; do
      [ -f "$f" ] && cp -f "$f" /system/dashboard-ui/vanvy/core/ 2>/dev/null
    done
  fi
  # 2. 覆盖旧版 main.js (如果存在) — 防镜像旧版复活
  if [ -f "$VANVY_DIR/main.js" ]; then
    mkdir -p "$CRX" 2>/dev/null
    cp -f "$VANVY_DIR/main.js" "$CRX/main.js" 2>/dev/null
  fi
  # 3. 移除 index.html 中的 config.js 注入 (官方版不需要)
  if grep -q 'emby-crx/config.js' "$INDEX" 2>/dev/null; then
    sed -i '/emby-crx\/config\.js/d' "$INDEX"
  fi
  # 4. 恢复 JAV config.json (若持久卷有)
  if [ -f "$VANVY_DIR/config.json" ]; then
    cp -f "$VANVY_DIR/config.json" /system/dashboard-ui/config.json 2>/dev/null
  fi
  # 4.5 清理镜像自带旧版 emby-crx 注入 (recreate 后镜像层自带会复活, 与我们的冲突)
  if grep -q 'emby-crx/main.js' "$INDEX" 2>/dev/null; then
    sed -i '/emby-crx\/style.css/d; /emby-crx\/common-utils.js/d; /emby-crx\/jquery/d; /emby-crx\/md5/d; /emby-crx\/config.js/d; /emby-crx\/main.js/d' "$INDEX"
    echo "  ✓ 已清理镜像旧版 emby-crx 注入"
  fi
  # 5. 从快照恢复 index.html 注入 (recreate 后 index.html 回镜像层, 注入全丢)
  if [ -f "$VANVY_DIR/injections.txt" ]; then
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      grep -qF "$line" "$INDEX" || {
        # 插到 </head> 前
        if grep -q '</head>' "$INDEX" 2>/dev/null; then
          sed -i "s|</head>|$line\n</head>|" "$INDEX"
        fi
      }
    done < "$VANVY_DIR/injections.txt"
    echo "  ✓ index.html 注入已恢复"
  fi
  echo "  ✓ vanvy 美化已恢复"
fi
# ==== end vanvy-beautify 持久化 ====
EOF
  docker cp "$hook" "$CONTAINER:/tmp/vanvy-persist-hook.sh" 2>/dev/null
  # 插到 exit 0 前
  docker exec "$CONTAINER" sh -c "
    EXT='$ext_file'
    if grep -q '^exit 0' \"\$EXT\"; then
      awk 'BEGIN{while((getline l < \"/tmp/vanvy-persist-hook.sh\")>0) h=h l \"\\n\"} /^exit 0/ && !d {printf \"%s\", h; d=1} {print}' \"\$EXT\" > \"\$EXT.new\" && mv \"\$EXT.new\" \"\$EXT\"
    else
      cat /tmp/vanvy-persist-hook.sh >> \"\$EXT\"
    fi
    rm -f /tmp/vanvy-persist-hook.sh
    echo '  ✓ ext.sh 持久化钩子已写入'
  " 2>&1 | sed 's/^/    /'
  rm -f "$hook"
  c_ok "✓ ext.sh 钩子已接管 (容器重建后自动恢复)"
}

# 完整持久化
persist_all() {
  persist_assets
  persist_write_hook
}
