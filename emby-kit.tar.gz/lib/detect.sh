#!/usr/bin/env bash
# =============================================================================
#  Emby 美化引擎 · 镜像体检引擎 (detect)
#  ---------------------------------------------------------------------------
#  功能: 识别容器/镜像类型/Emby版本/内置美化/ext.sh机制, 输出体检报告
#  让脚本"看懂"目标镜像, 给出可落地的美化方案, 绕开开心版内置坑
# =============================================================================

# 识别容器 (自动/手动)
detect_container() {
  local list i=1
  list=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -iE "emby" | head -10)
  if [ -z "$list" ]; then
    c_err "未找到运行中的 Emby 容器"
    return 1
  fi
  if [ -z "$CONTAINER" ]; then
    # 自动: 只有一个就选它, 多个让用户选
    local count
    count=$(echo "$list" | wc -l)
    if [ "$count" = "1" ]; then
      CONTAINER="$list"
    else
      c_info "检测到多个 Emby 容器:"
      echo "$list" | while read -r c; do echo "  [$((i++))] $c"; done
      c_ask "选择容器: "
      safe_read sel "1"
      CONTAINER=$(echo "$list" | sed -n "${sel}p")
    fi
  fi
  docker inspect "$CONTAINER" >/dev/null 2>&1 || { c_err "容器 $CONTAINER 不存在"; return 1; }
  c_ok "容器: $CONTAINER"
}

# 识别镜像类型
detect_image() {
  IMAGE_TYPE="unknown"; IMAGE_FULL=""
  IMAGE_FULL=$(docker inspect "$CONTAINER" --format '{{.Config.Image}}' 2>/dev/null)
  case "$IMAGE_FULL" in
    *amilys*)     IMAGE_TYPE="amilys" ;;
    *emby/embyserver*|*embyserver*)
      if echo "$IMAGE_FULL" | grep -qi "amilys\|docker.vanvy\|dockerhub.vanvy"; then
        IMAGE_TYPE="amilys"
      else
        IMAGE_TYPE="official"
      fi
      ;;
    *linuxserver/emby*) IMAGE_TYPE="linuxserver" ;;
    *) IMAGE_TYPE="unknown" ;;
  esac
  # 补充: 镜像源含 vanvy 也是开心版
  echo "$IMAGE_FULL" | grep -qE "vanvy" && [ "$IMAGE_TYPE" = "unknown" ] && IMAGE_TYPE="amilys"
  c_info "镜像: $IMAGE_FULL (类型: $IMAGE_TYPE)"
}

# 识别 Emby 版本 (API优先, 兜底 index.html)
detect_version() {
  VER=""; VER_SRC=""
  local port
  port=$(docker port "$CONTAINER" 2>/dev/null | grep -E "^8096/tcp" | head -1 | grep -oE '[0-9]+$' | head -1)
  # 尝试 API
  local api_ver
  if [ -n "$port" ]; then
    api_ver=$(curl -s --max-time 5 "http://127.0.0.1:$port/emby/System/Info/Public" 2>/dev/null | grep -oE '"Version":"[^"]+"' | cut -d'"' -f4)
  fi
  if [ -n "$api_ver" ]; then
    VER="$api_ver"; VER_SRC="api"
  else
    # 兜底: 从容器内 index.html 特征判断
    if docker exec "$CONTAINER" sh -c "grep -q 'modules/fonts' /system/dashboard-ui/index.html" 2>/dev/null; then
      VER="4.9"; VER_SRC="html"
    elif docker exec "$CONTAINER" sh -c "grep -q 'require.js' /system/dashboard-ui/index.html" 2>/dev/null; then
      VER="4.8"; VER_SRC="html"
    fi
  fi
  # 提取主版本号
  case "$VER" in
    4.8*) VER_MAJOR="4.8" ;;
    4.9*) VER_MAJOR="4.9" ;;
    *) VER_MAJOR="" ;;
  esac
  c_info "版本: ${VER:-未知} (来源: $VER_SRC)"
}

# 检测镜像内置美化 (开心版坑)
detect_builtin() {
  BUILTIN_CRX=0; BUILTIN_DANMAKU=0; BUILTIN_EXTJS=0; BUILTIN_HAPPY=0
  # 内置 emby-crx (index.html 注入)
  if docker exec "$CONTAINER" sh -c "grep -q 'emby-crx/main.js' /system/dashboard-ui/index.html" 2>/dev/null; then
    BUILTIN_CRX=1
  fi
  # 内置弹幕
  if docker exec "$CONTAINER" sh -c "grep -q 'danmaku.min.js' /system/dashboard-ui/index.html" 2>/dev/null; then
    BUILTIN_DANMAKU=1
  fi
  # 内置 ext.js (开心版扩展开关)
  if docker exec "$CONTAINER" sh -c "ls /system/dashboard-ui/ext.js" 2>/dev/null; then
    BUILTIN_EXTJS=1
  fi
  # 内置 embyHappy
  if docker exec "$CONTAINER" sh -c "ls /system/dashboard-ui/embyHappy.js" 2>/dev/null; then
    BUILTIN_HAPPY=1
  fi
}

# 检测 ext.sh 机制 (开心版轮播禁用源头)
detect_ext_hook() {
  EXT_HOOK=0; EXT_MEDIA_ID=""
  if docker exec "$CONTAINER" sh -c "[ -f /config/config/ext.sh ]" 2>/dev/null; then
    EXT_HOOK=1
    EXT_MEDIA_ID=$(docker exec "$CONTAINER" sh -c "grep '^MediaId=' /config/config/ext.sh 2>/dev/null | cut -d'\"' -f2" 2>/dev/null)
  fi
}

# 检测容器 dashboard 目录
detect_dashboard_dir() {
  local d
  for d in /system/dashboard-ui /app/emby/system/dashboard-ui /usr/lib/emby-server/web; do
    if docker exec "$CONTAINER" sh -c "[ -f '$d/index.html' ]" 2>/dev/null; then
      DASHBOARD_DIR="$d"; return 0
    fi
  done
  DASHBOARD_DIR="/system/dashboard-ui"
  return 1
}

# 完整体检: 输出报告
run_health_check() {
  c_info "════════ 镜像体检 ════════"
  detect_container || return 1
  detect_image
  detect_version
  detect_dashboard_dir || true
  detect_builtin
  detect_ext_hook

  # 体检报告
  echo ""
  echo "  ┌────────────────────────────────────────────────────────────┐"
  echo "  │  🧬 镜像体检报告                                          │"
  echo "  ├────────────────────────────────────────────────────────────┤"
  printf '  │  📦 容器       %-40s│\n' "$CONTAINER"
  printf '  │  🖼️  镜像       %-40s│\n' "$IMAGE_FULL"
  printf '  │  📊 Emby 版本  %-40s│\n' "$VER"
  echo "  ├────────────────────────────────────────────────────────────┤"
  # 镜像类型说明
  case "$IMAGE_TYPE" in
    amilys)       echo "  │  🔍 镜像类型: 开心版 (amilys)                          │" ;;
    official)     echo "  │  🔍 镜像类型: 官方版                                  │" ;;
    linuxserver)  echo "  │  🔍 镜像类型: LinuxServer 版                          │" ;;
    *)            echo "  │  🔍 镜像类型: 未知                                    │" ;;
  esac
  # 内置美化说明 (友好措辞, 重新检测避免变量错乱)
  local builtin_desc="无"
  docker exec "$CONTAINER" sh -c "grep -q 'emby-crx/main.js' '$DASHBOARD_DIR/index.html'" 2>/dev/null && builtin_desc="旧版 emby-crx (将自动覆盖)"
  docker exec "$CONTAINER" sh -c "grep -q 'danmaku.min.js' '$DASHBOARD_DIR/index.html'" 2>/dev/null && builtin_desc="$builtin_desc + 内置弹幕"
  docker exec "$CONTAINER" sh -c "ls '$DASHBOARD_DIR/ext.js'" 2>/dev/null && builtin_desc="$builtin_desc + 扩展框架"
  printf '  │  🔧 内置美化   %-40s│\n' "${builtin_desc:0:42}"
  if [ "$EXT_HOOK" = "1" ]; then
    echo "  │  ⚙️  启动钩子: 存在 (ext.sh)                                │"
  fi
  echo "  └────────────────────────────────────────────────────────────┘"

  # 结论 (友好提示)
  echo ""
  if [ "$IMAGE_TYPE" = "amilys" ]; then
    c_warn "💡 提示: 当前为开心版镜像, 内置旧版美化且启动钩子会重置配置。"
    c_warn "   本工具将自动: ① 覆盖为官方美化 ② 接管启动钩子 (持久化, 重建不丢)"
  elif [ "$BUILTIN_CRX" = "1" ]; then
    c_warn "💡 提示: 检测到旧版 emby-crx 注入, 安装新美化前将自动覆盖为官方版。"
  fi
  if [ "$BUILTIN_DANMAKU" = "1" ] && [ "${FEATURES:-}" != "" ] && [ "$(echo "${FEATURES:-}" | grep -c danmaku)" != "0" ]; then
    c_warn "💡 提示: 镜像内置弹幕与我们的弹幕组件冲突, 建议不装弹幕或先移除内置。"
  fi
  c_ok "✅ 体检完成, 已为你准备好可落地的美化方案!"
}
