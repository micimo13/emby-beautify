#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 持久化引擎 (persist)
#  ---------------------------------------------------------------------------
#  - 资源全量备份到 /config/vanvy-v2/
#  - amilys 镜像: 写入 ext.sh 钩子, 容器每次启动自动恢复
#  - 官方/lsio: 无钩子, 记录 dashboard_path + 注入快照, --restore 一键恢复
# =============================================================================

set -u

# ── 持久化资源 ──
persist_assets() {
  local persist_dir="/config/vanvy-v2"
  docker exec "$CONTAINER" sh -c "mkdir -p '$persist_dir'" 2>/dev/null
  # 备份 vanvy/v2 整个目录
  docker exec "$CONTAINER" sh -c "
    rm -rf '$persist_dir/vanvy-v2'
    cp -r '$DASHBOARD_DIR/vanvy/v2' '$persist_dir/vanvy-v2' 2>/dev/null
  " 2>/dev/null
  # 记录注入行快照 + dashboard 路径
  docker exec "$CONTAINER" sh -c "
    grep 'vanvy/v2/' '$DASHBOARD_DIR/index.html' > '$persist_dir/injections.txt' 2>/dev/null
    echo '$DASHBOARD_DIR' > '$persist_dir/dashboard_path.txt' 2>/dev/null
  " 2>/dev/null
  c_ok "✓ 美化已持久化 → /config/vanvy-v2/"
}

# ── 写入 ext.sh 钩子 (amilys) ──
persist_write_hook() {
  [ "$EXT_HOOK" = "1" ] || return 0
  local ext_file="/config/config/ext.sh"
  local marker="vanvy-v2-persist"
  docker exec "$CONTAINER" sh -c "mkdir -p /config/config 2>/dev/null; [ -f '$ext_file' ] || { echo '#!/bin/sh' > '$ext_file'; chmod +x '$ext_file'; }"
  if docker exec "$CONTAINER" sh -c "grep -q '$marker' '$ext_file'" 2>/dev/null; then
    c_ok "✓ 持久化钩子已存在"
    return 0
  fi
  docker exec "$CONTAINER" sh -c "cp '$ext_file' '$ext_file.bak.\$(date +%Y%m%d-%H%M%S)' 2>/dev/null"
  local hook="/tmp/vanvy-v2-hook.sh"
  cat > "$hook" << EOF
#!/bin/sh
# ==== vanvy-v2 持久化部署 ====
VANVY='/config/vanvy-v2'
INDEX='$DASHBOARD_DIR/index.html'
if [ -d "\$VANVY" ]; then
  if [ -d "\$VANVY/vanvy-v2" ]; then
    rm -rf '$DASHBOARD_DIR/vanvy/v2'
    mkdir -p '$DASHBOARD_DIR/vanvy'
    cp -r "\$VANVY/vanvy-v2" '$DASHBOARD_DIR/vanvy/v2' 2>/dev/null
  fi
  if [ -f "\$VANVY/injections.txt" ]; then
    while IFS= read -r line; do
      [ -z "\$line" ] && continue
      grep -qF "\$line" "\$INDEX" || {
        if grep -q '</head>' "\$INDEX" 2>/dev/null; then
          sed -i "s|</head>|\$line\n</head>|" "\$INDEX"
        else
          sed -i "s|<body|\$line\n<body|" "\$INDEX"
        fi
      }
    done < "\$VANVY/injections.txt"
  fi
  echo "  ✓ vanvy-v2 美化已恢复"
fi
# ==== end vanvy-v2 持久化 ====
EOF
  docker cp "$hook" "$CONTAINER:/tmp/vanvy-v2-hook.sh" 2>/dev/null
  docker exec "$CONTAINER" sh -c "
    EXT='$ext_file'
    if grep -q '^exit 0' \"\$EXT\" 2>/dev/null; then
      awk 'BEGIN{while((getline l < \"/tmp/vanvy-v2-hook.sh\")>0) h=h l \"\\n\"} /^exit 0/ && !d {printf \"%s\", h; d=1} {print}' \"\$EXT\" > \"\$EXT.new\" && mv \"\$EXT.new\" \"\$EXT\"
    else
      cat /tmp/vanvy-v2-hook.sh >> \"\$EXT\"
    fi
    rm -f /tmp/vanvy-v2-hook.sh
  " 2>/dev/null
  rm -f "$hook"
  c_ok "✓ 已接管启动钩子 (容器重建自动恢复)"
}

# ── 恢复 (--restore) ──
restore_from_persist() {
  local persist_dir="/config/vanvy-v2"
  if ! docker exec "$CONTAINER" sh -c "[ -d '$persist_dir' ]" 2>/dev/null; then
    c_warn "未找到持久化数据, 无需恢复"
    return 0
  fi
  c_info "从持久卷恢复美化..."
  docker exec "$CONTAINER" sh -c "
    if [ -d '$persist_dir/vanvy-v2' ]; then
      rm -rf '$DASHBOARD_DIR/vanvy/v2'
      mkdir -p '$DASHBOARD_DIR/vanvy'
      cp -r '$persist_dir/vanvy-v2' '$DASHBOARD_DIR/vanvy/v2' 2>/dev/null
    fi
  " 2>/dev/null
  docker exec "$CONTAINER" sh -c "
    INDEX='$DASHBOARD_DIR/index.html'
    cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.pre-restore.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
    if [ -f '$persist_dir/injections.txt' ]; then
      while IFS= read -r line; do
        [ -z \"\$line\" ] && continue
        grep -qF \"\$line\" \"\$INDEX\" || {
          if grep -q '</head>' \"\$INDEX\" 2>/dev/null; then
            sed -i \"s|</head>|\$line\n</head>|\" \"\$INDEX\"
          else
            sed -i \"s|<body|\$line\n<body|\" \"\$INDEX\"
          fi
        }
      done < '$persist_dir/injections.txt'
    fi
  " 2>/dev/null
  c_ok "✅ 美化已恢复!"
}

# ── 完整持久化 ──
persist_all() {
  persist_assets
  if [ "$EXT_HOOK" = "1" ]; then
    persist_write_hook
  else
    c_warn "此镜像无启动钩子, 容器重建后请运行: install.sh --restore"
  fi
}
