#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 环境检测引擎 (detect)
#  ---------------------------------------------------------------------------
#  功能: 自动识别 Emby 容器 / 镜像类型 / 版本 / Web目录 / index.html纯净度
#  输出全局变量:
#    CONTAINER     容器名
#    IMAGE_TYPE    official|amilys|linuxserver|unknown
#    IMAGE_FULL    完整镜像名
#    VER           版本号 (如 4.8.11.0)
#    VER_MAJOR     主版本 (4.8|4.9|4.10|unknown)
#    DASHBOARD_DIR web目录
#    HTML_DIRTY    0=纯净 1=有注入痕迹
#    EXT_HOOK      0/1 是否有 ext.sh 启动钩子
# =============================================================================

set -u

# ── 识别容器 (自动/手动) ──
detect_container() {
  local list i=1
  list=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -iE "emby" | head -10)
  if [ -z "$list" ]; then
    c_err "未找到运行中的 Emby 容器"
    return 1
  fi
  if [ -z "${CONTAINER:-}" ]; then
    local count
    count=$(echo "$list" | wc -l | tr -d ' ')
    if [ "$count" = "1" ]; then
      CONTAINER="$list"
    else
      c_info "检测到多个 Emby 容器:"
      echo "$list" | nl -w2 -s'] '
      c_ask "选择容器 [1-$count, 默认 1]: "
      safe_read sel "1"
      sel=$(echo "$sel" | tr -dc '0-9'); [ -z "$sel" ] && sel="1"
      [ "$sel" -lt 1 ] && sel="1"; [ "$sel" -gt "$count" ] && sel="1"
      CONTAINER=$(echo "$list" | sed -n "${sel}p")
      c_ok "已选择: $CONTAINER"
    fi
  fi
  docker inspect "$CONTAINER" >/dev/null 2>&1 || { c_err "容器 $CONTAINER 不存在"; return 1; }
}

# ── 识别镜像类型 ──
detect_image() {
  IMAGE_TYPE="unknown"; IMAGE_FULL=""
  IMAGE_FULL=$(docker inspect "$CONTAINER" --format '{{.Config.Image}}' 2>/dev/null)
  case "$IMAGE_FULL" in
    *linuxserver/emby*) IMAGE_TYPE="linuxserver" ;;
    *amilys*)           IMAGE_TYPE="amilys" ;;
    *emby/embyserver*|*embyserver*)
      if echo "$IMAGE_FULL" | grep -qi "amilys\|vanvy"; then IMAGE_TYPE="amilys"
      else IMAGE_TYPE="official"; fi ;;
    *) IMAGE_TYPE="unknown" ;;
  esac
}

# ── 探测 Web 目录 (支持所有镜像布局) ──
detect_dashboard_dir() {
  local d
  for d in /system/dashboard-ui /app/emby/system/dashboard-ui /usr/lib/emby-server/web /opt/emby-server/system/dashboard-ui; do
    if docker exec "$CONTAINER" sh -c "[ -f '$d/index.html' ]" 2>/dev/null; then
      DASHBOARD_DIR="$d"; return 0
    fi
  done
  DASHBOARD_DIR=$(docker exec "$CONTAINER" sh -c "find / -maxdepth 5 -name index.html -path '*dashboard*' 2>/dev/null | head -1 | xargs dirname" 2>/dev/null)
  [ -z "$DASHBOARD_DIR" ] && DASHBOARD_DIR="/system/dashboard-ui" && return 1
  return 0
}

# ── 识别 Emby 版本 (API 优先, 兜底文件) ──
detect_version() {
  VER=""; VER_SRC=""
  local api_ver
  api_ver=$(docker exec "$CONTAINER" sh -c "curl -s --max-time 5 'http://127.0.0.1:8096/emby/System/Info/Public' 2>/dev/null | grep -oE '\"Version\":\"[^\"]+\"' | cut -d'\"' -f4" 2>/dev/null)
  if [ -z "$api_ver" ]; then
    api_ver=$(docker exec "$CONTAINER" sh -c "wget -qO- --timeout=5 'http://127.0.0.1:8096/emby/System/Info/Public' 2>/dev/null | grep -oE '\"Version\":\"[^\"]+\"' | cut -d'\"' -f4" 2>/dev/null)
  fi
  if [ -n "$api_ver" ]; then VER="$api_ver"; VER_SRC="api"
  else
    local port
    port=$(docker port "$CONTAINER" 2>/dev/null | grep -E "^8096/tcp" | head -1 | grep -oE '[0-9]+$' | head -1)
    if [ -n "$port" ]; then
      api_ver=$(curl -s --max-time 5 "http://127.0.0.1:$port/emby/System/Info/Public" 2>/dev/null | grep -oE '"Version":"[^"]+"' | cut -d'"' -f4)
      [ -n "$api_ver" ] && { VER="$api_ver"; VER_SRC="api"; }
    fi
  fi
  if [ -z "$VER" ]; then
    VER=$(docker exec "$CONTAINER" sh -c "grep -oE '4\.[0-9]+\.[0-9]+\.[0-9]+' '$DASHBOARD_DIR/app.js' 2>/dev/null | head -1" 2>/dev/null)
    [ -n "$VER" ] && VER_SRC="app.js"
  fi
  case "$VER" in
    4.8*) VER_MAJOR="4.8" ;;
    4.9*) VER_MAJOR="4.9" ;;
    4.10*) VER_MAJOR="4.10" ;;
    *) VER_MAJOR="unknown" ;;
  esac
}

# ── index.html 纯净度诊断 (v2 核心: 小白安全的第一道关) ──
detect_html_purity() {
  HTML_DIRTY=0
  HTML_NOTE="纯净"
  local has_head_anchor inject_count
  has_head_anchor=$(docker exec "$CONTAINER" sh -c "grep -c '</head>' '$DASHBOARD_DIR/index.html'" 2>/dev/null | tr -d ' ')
  inject_count=$(docker exec "$CONTAINER" sh -c "grep -cE 'vanvy/|emby-crx|emby-js/|danmaku|ext\.js' '$DASHBOARD_DIR/index.html'" 2>/dev/null | tr -d ' ')
  # 污染判定: 无 </head> 锚点 或 有注入痕迹
  if [ "${has_head_anchor:-0}" = "0" ] || [ "${inject_count:-0}" -gt 0 ]; then
    HTML_DIRTY=1
    HTML_NOTE="已污染 (注入${inject_count}处, </head>锚点:${has_head_anchor})"
  fi
}

# ── 检测持久化钩子 (amilys 有 ext.sh) ──
detect_ext_hook() {
  EXT_HOOK=0
  docker exec "$CONTAINER" sh -c "[ -f /config/config/ext.sh ]" 2>/dev/null && EXT_HOOK=1
}

# ── 环境就绪检查 (安装前调用) ──
run_health_check() {
  detect_container || return 1
  detect_image
  detect_dashboard_dir || true
  detect_version
  detect_html_purity
  detect_ext_hook
  c_ok "✓ 环境就绪: $CONTAINER ($IMAGE_FULL · Emby $VER)"
}

# ── 输出诊断卡 (v2 新增: 安装前让用户看清环境) ──
print_diagnosis() {
  echo ""
  echo "  ┌────────────────────────────────────────────────────────┐"
  echo "  │  🔍 环境诊断报告                                        │"
  echo "  ├────────────────────────────────────────────────────────┤"
  printf '  │  容器:     %-46s │\n' "$CONTAINER"
  printf '  │  镜像:     %-46s │\n' "$(echo $IMAGE_FULL | cut -c1-46)"
  printf '  │  版本:     %-46s │\n' "Emby $VER (适配: $VER_MAJOR)"
  printf '  │  Web目录:  %-46s │\n' "$DASHBOARD_DIR"
  printf '  │  html状态: %-46s │\n' "$HTML_NOTE"
  printf '  │  启动钩子: %-46s │\n' "$([ "$EXT_HOOK" = "1" ] && echo '有 (amilys 自愈)' || echo '无 (需 --restore)')"
  echo "  └────────────────────────────────────────────────────────┘"
  echo ""
}
