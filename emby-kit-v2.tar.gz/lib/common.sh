#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 公共函数库
# =============================================================================

C_INFO='\033[1;36m'; C_OK='\033[1;32m'; C_WARN='\033[1;33m'
C_ERR='\033[1;31m'; C_ASK='\033[1;35m'; C_OFF='\033[0m'

c_info()  { printf "${C_INFO}[信息]${C_OFF} %s\n" "$*"; }
c_ok()    { printf "${C_OK}[成功]${C_OFF} %s\n" "$*"; }
c_warn()  { printf "${C_WARN}[警告]${C_OFF} %s\n" "$*"; }
c_err()   { printf "${C_ERR}[错误]${C_OFF} %s\n" "$*"; }
c_ask()   { printf "${C_ASK}[询问]${C_OFF} %s" "$*"; }

die() { c_err "$*"; exit 1; }

# 从用户读取输入 (终端/管道/无tty 全兼容, 永不死等)
read_from_user() {
  local var="$1" default="${2:-}" val=""
  if [ -t 0 ]; then
    read -r val
  else
    { read -r val < /dev/tty; } 2>/dev/null || read -r val
  fi
  [ -z "$val" ] && val="$default"
  eval "$var=\"$val\""
}

safe_read() { read_from_user "$@"; }

tty_available() { ( exec 3<> /dev/tty ) 2>/dev/null; }

# 健壮多选解析 (兼容全角/顿号/空格)
parse_multi() {
  local raw="$1"
  raw="${raw//，/ }"; raw="${raw//、/ }"; raw="${raw//,/ }"
  raw="${raw//０/0}"; raw="${raw//１/1}"; raw="${raw//２/2}"; raw="${raw//３/3}"
  raw="${raw//４/4}"; raw="${raw//５/5}"; raw="${raw//６/6}"; raw="${raw//７/7}"
  raw="${raw//８/8}"; raw="${raw//９/9}"
  raw="${raw//　/ }"
  for token in $raw; do
    token=$(printf '%s' "$token" | tr -dc '0-9')
    [ -z "$token" ] && continue
    echo "$token"
  done
}

# 确认 (默认N)
confirm() {
  c_ask "$1 [y/N]: "
  local ans=""
  read_from_user ans
  [ "$ans" = "y" ] || [ "$ans" = "Y" ]
}
