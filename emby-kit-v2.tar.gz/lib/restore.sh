#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 纯净 html 还原引擎 (restore)
#  ---------------------------------------------------------------------------
#  4 级纯净来源, 逐级兜底:
#    1. 镜像原始层  docker create <image> → docker cp index.html (最纯净)
#    2. pristine 备份 /config/backups/emby-beautify/index.html.pristine.*
#    3. 项目内置模板 templates/index-<VER_MAJOR>.html (离线可用)
#    4. 清理注入行 sed 移除所有已知注入 (最后手段)
#  还原前自动备份当前污染 html (可回滚)
# =============================================================================

set -u

# ── 还原纯净 html (返回 0=成功) ──
restore_pure_html() {
  c_info "🧹 还原纯净 index.html (4级来源兜底)..."

  # 还原前备份当前污染 html
  docker exec "$CONTAINER" sh -c "
    mkdir -p /config/backups/emby-beautify
    cp '$DASHBOARD_DIR/index.html' \"/config/backups/emby-beautify/index.html.dirty.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
  " 2>/dev/null && c_ok "✓ 污染 html 已备份 (可回滚)"

  # ── 来源 1: 镜像原始层 ──
  c_info "尝试来源1: 镜像原始层..."
  local img cid restored=0
  img=$(docker inspect "$CONTAINER" --format '{{.Config.Image}}' 2>/dev/null)
  cid=$(docker create "$img" 2>/dev/null)
  if [ -n "$cid" ]; then
    if docker cp "$cid:$DASHBOARD_DIR/index.html" /tmp/vanvy-v2-pure.html 2>/dev/null \
      && [ -s /tmp/vanvy-v2-pure.html ] \
      && ! grep -qE 'vanvy/|emby-crx|emby-js/' /tmp/vanvy-v2-pure.html 2>/dev/null; then
      docker cp /tmp/vanvy-v2-pure.html "$CONTAINER:$DASHBOARD_DIR/index.html" 2>/dev/null
      c_ok "✓ 已从镜像原始层还原纯净 html"
      restored=1
    else
      c_warn "  镜像原始层含内置美化或无 index.html, 尝试来源2..."
    fi
    rm -f /tmp/vanvy-v2-pure.html
    docker rm "$cid" >/dev/null 2>&1
  fi

  # ── 来源 2: pristine 备份 ──
  if [ "$restored" = "0" ]; then
    c_info "尝试来源2: pristine 备份..."
    local pristine
    pristine=$(docker exec "$CONTAINER" sh -c "ls -t /config/backups/emby-beautify/index.html.pristine.* 2>/dev/null | head -1" 2>/dev/null)
    if [ -n "$pristine" ]; then
      local p_dirty
      p_dirty=$(docker exec "$CONTAINER" sh -c "grep -cE 'vanvy/|emby-crx|emby-js/' '$pristine'" 2>/dev/null | tr -d ' ')
      if [ "${p_dirty:-1}" = "0" ]; then
        docker exec "$CONTAINER" sh -c "cp '$pristine' '$DASHBOARD_DIR/index.html'" 2>/dev/null \
          && c_ok "✓ 已从 pristine 备份还原: $(basename "$pristine")" && restored=1
      else
        c_warn "  pristine 备份也被污染, 尝试来源3..."
      fi
    else
      c_warn "  无 pristine 备份, 尝试来源3..."
    fi
  fi

  # ── 来源 3: 项目内置模板 ──
  if [ "$restored" = "0" ]; then
    c_info "尝试来源3: 项目内置模板..."
    local tpl="$SCRIPT_DIR/templates/index-${VER_MAJOR}.html"
    if [ -f "$tpl" ]; then
      docker cp "$tpl" "$CONTAINER:$DASHBOARD_DIR/index.html" 2>/dev/null \
        && c_ok "✓ 已从内置模板还原 (templates/index-${VER_MAJOR}.html)" && restored=1
    else
      c_warn "  无匹配模板 (templates/index-${VER_MAJOR}.html), 尝试来源4..."
    fi
  fi

  # ── 来源 4: 清理注入行 ──
  if [ "$restored" = "0" ]; then
    c_warn "尝试来源4: 清理现有 html 注入行 (最后手段)..."
    docker exec "$CONTAINER" sh -c "
      INDEX='$DASHBOARD_DIR/index.html'
      sed -i '/vanvy\//d; /emby-crx/d; /emby-js\//d; /danmaku/d; /ext\.js/d; /require\.js/d' \"\$INDEX\"
      # 若仍无 </head> 锚点, 在 <body 前补一个 (保证后续注入可用)
      if ! grep -q '</head>' \"\$INDEX\"; then
        sed -i 's|<body|</head>\n<body|' \"\$INDEX\"
      fi
    " 2>/dev/null
    # 验证锚点
    local anchor
    anchor=$(docker exec "$CONTAINER" sh -c "grep -c '</head>' '$DASHBOARD_DIR/index.html'" 2>/dev/null | tr -d ' ')
    if [ "${anchor:-0}" -gt 0 ]; then
      c_ok "✓ 注入行已清理, </head> 锚点已修复"
      restored=1
    else
      c_err "❌ 清理后仍无 </head> 锚点, html 结构异常!"
    fi
  fi

  if [ "$restored" = "1" ]; then
    c_ok "✅ 纯净 html 就绪, 可安全部署"
    return 0
  fi
  return 1
}

# ── 从当前 html 增量部署前, 确保有注入锚点 ──
ensure_inject_anchor() {
  local anchor
  anchor=$(docker exec "$CONTAINER" sh -c "grep -c '</head>' '$DASHBOARD_DIR/index.html'" 2>/dev/null | tr -d ' ')
  if [ "${anchor:-0}" = "0" ]; then
    c_warn "当前 html 无 </head> 锚点, 自动修复..."
    docker exec "$CONTAINER" sh -c "
      INDEX='$DASHBOARD_DIR/index.html'
      cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
      sed -i 's|<body|</head>\n<body|' \"\$INDEX\"
    " 2>/dev/null
  fi
}
