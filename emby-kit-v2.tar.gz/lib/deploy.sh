#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 部署引擎 (deploy)
#  ---------------------------------------------------------------------------
#  核心架构: 单点注入
#    index.html 只注入一行:
#      <script src="vanvy/v2/loader.js" data-profile="cinema-blackgold"></script>
#    loader.js 运行时动态加载该方案的所有 css/js
#  优势:
#    - 卸载 = 删一行 + 删 vanvy/v2 目录
#    - 升级 = 换 loader.js
#    - 冲突 = 方案白名单, 不存在多 script 打架
#    - 纯净 html 恢复后一行可复原
# =============================================================================

set -u

INJECT_MARKER='vanvy/v2/loader.js'

# ── 推资源到容器 ──
push_assets() {
  local src_dir="$1" dst_dir="$2"
  docker exec "$CONTAINER" sh -c "mkdir -p '$dst_dir'" 2>/dev/null
  local count=0
  for f in "$src_dir"/*; do
    [ -f "$f" ] || continue
    local fname
    fname="$(basename "$f")"
    docker cp "$f" "$CONTAINER:$dst_dir/$fname" 2>/dev/null || { c_err "复制失败: $fname"; return 1; }
    count=$((count+1))
  done
  echo "    ✓ 复制 $count 文件 → $dst_dir"
}

# ── 单点注入 loader 到 index.html (幂等) ──
inject_loader() {
  local profile="$1"
  # 生成 loader 注入行 (带方案参数)
  local inject_line="<script src=\"vanvy/v2/loader.js\" data-profile=\"$profile\" defer></script>"

  # 已存在则更新 data-profile (换方案)
  if docker exec "$CONTAINER" sh -c "grep -q '$INJECT_MARKER' '$DASHBOARD_DIR/index.html'" 2>/dev/null; then
    docker exec "$CONTAINER" sh -c "
      INDEX='$DASHBOARD_DIR/index.html'
      cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
      sed -i \"s|<script src=\\\"vanvy/v2/loader.js\\\"[^>]*>|$inject_line|\" \"\$INDEX\"
    " 2>/dev/null
    c_ok "✓ loader 已更新方案 → $profile"
    return 0
  fi

  # 全新注入: 在 </head> 前插入
  docker exec -i "$CONTAINER" sh -c "
    set -e
    INDEX='$DASHBOARD_DIR/index.html'
    if grep -q '$INJECT_MARKER' \"\$INDEX\"; then echo '已存在'; exit 0; fi
    mkdir -p /config/backups/emby-beautify
    cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\" || exit 1
    if grep -q '</head>' \"\$INDEX\"; then
      sed -i \"s|</head>|$inject_line\n</head>|\" \"\$INDEX\"
    elif grep -q '<body' \"\$INDEX\"; then
      sed -i \"s|<body|$inject_line\n<body|\" \"\$INDEX\"
    else
      echo '[错误] 无 </head> 也无 <body 锚点'; exit 1
    fi
    # 验证
    if grep -q '$INJECT_MARKER' \"\$INDEX\"; then echo \"[注入] loader 完成\"; else echo '[警告] 注入验证失败'; fi
  " 2>&1 | sed 's/^/    /'
  c_ok "✓ 单点 loader 已注入 (data-profile=$profile)"
}

# ── 部署方案 (profile) ──
deploy_profile() {
  local profile="$1"
  local profile_dir="$SCRIPT_DIR/profiles/$profile"
  [ -d "$profile_dir" ] || { c_err "方案不存在: $profile"; return 1; }

  c_info "📦 部署方案 [$profile] ..."

  # 1. 推 runtime 核心 (loader/skin/panel/themes)
  push_assets "$SCRIPT_DIR/runtime" "$DASHBOARD_DIR/vanvy/v2/runtime" || return 1

  # 2. 推 profile 资源
  push_assets "$profile_dir" "$DASHBOARD_DIR/vanvy/v2/profiles/$profile" || return 1

  # 3. 推 components (该方案依赖的轮播/功能)
  local deps
  deps=$(cat "$profile_dir/profile.json" 2>/dev/null | grep -oE '"deps":\s*\[[^]]*\]' | grep -oE '"[a-z_]+"' | tr -d '"' | tr '\n' ' ')
  for dep in $deps; do
    if [ -d "$SCRIPT_DIR/components/$dep" ]; then
      push_assets "$SCRIPT_DIR/components/$dep" "$DASHBOARD_DIR/vanvy/v2/components/$dep" || true
    fi
  done

  # 4. 单点注入 loader
  inject_loader "$profile"

  c_ok "✅ 方案 [$profile] 部署完成"
}

# ── 卸载 (删注入行 + 删 vanvy/v2 目录) ──
undeploy() {
  c_info "🗑️ 卸载 Vanvy V2 美化..."
  docker exec "$CONTAINER" sh -c "
    INDEX='$DASHBOARD_DIR/index.html'
    cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
    grep -v 'vanvy/v2/' \"\$INDEX\" > \"\$INDEX.tmp\" && mv \"\$INDEX.tmp\" \"\$INDEX\"
    rm -rf '$DASHBOARD_DIR/vanvy/v2'
  " 2>/dev/null
  c_ok "✅ 已卸载 (注入行 + vanvy/v2 目录)"
}
