/* Vanvy V2 方案: retro (📼 复古胶片) */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: { id: 'retro', carouselTheme: 'midnight', carousel: 'banner_retro' },
    init: function () {
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var s = document.createElement('script');
      s.src = 'vanvy/v2/components/' + this.CONFIG.carousel + '/banner-' + this.CONFIG.carousel.replace('banner_', '') + '.js';
      document.head.appendChild(s);
    }
  };
})();
