/* Vanvy V2 方案: neo */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: { id: 'neo', carousel: 'banner_neo', carouselTheme: 'midnight' },
    init: function () {
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var self = this;
      // 1. 核心引擎
      this.load('runtime/vanvy-carousel-core.js', function () {
        // 2. 组件 CSS
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'vanvy/v2/components/banner_neo/style.css';
        document.head.appendChild(link);
        // 3. 组件 JS
        self.load('components/banner_neo/banner-neo.js', function () {
          // 4. 启动轮播 (等 DOM 就绪 + 核心引擎就绪)
          setTimeout(function () {
            try { window.VanvyCarouselCore.start('banner_neo'); } catch (e) {}
          }, 300);
        });
      });
    },
    load: function (src, cb) {
      if (document.querySelector('script[data-vanvy="' + src + '"]')) { cb(); return; }
      var s = document.createElement('script');
      s.src = 'vanvy/v2/' + src;
      s.setAttribute('data-vanvy', src);
      s.onload = cb; s.onerror = cb;
      document.head.appendChild(s);
    }
  };
})();
