/* Vanvy V2 方案: neo (霓虹赛博) */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: { id: 'neo', carouselTheme: 'midnight', carousel: 'banner_neo' },
    init: function () {
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var s = document.createElement('script');
      s.src = 'vanvy/v2/components/' + this.CONFIG.carousel + '/banner-neo.js';
      document.head.appendChild(s);
    }
  };
})();
