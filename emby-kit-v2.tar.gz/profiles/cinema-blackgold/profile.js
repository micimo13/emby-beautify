/* ═══════════════════════════════════════════════════════════
   Vanvy Emby Kit V2 · 方案激活器 (profile.js)
   ───────────────────────────────────────────────────────────
   loader 加载方案资源后调用: window.VanvyProfile.init()
   职责: 应用主题色 class + 加载轮播组件 + 初始化功能
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: {
      id: 'cinema-blackgold',
      carouselTheme: 'midnight',   // 主题色 class
      carousel: 'banner_cinema'    // 轮播组件
    },

    init: function () {
      // 1. 应用主题色 class (轮播/皮肤/面板都读这个)
      var root = document.documentElement;
      root.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);

      // 2. 加载轮播组件 JS (组件 css 已由 loader 预加载)
      var self = this;
      var carouselId = this.CONFIG.carousel; // banner_cinema
      var jsName = carouselId.replace('banner_', 'banner-'); // banner-cinema.js
      this.loadComponentJs('components/' + carouselId + '/' + jsName + '.js')
        .catch(function () { console.warn('[Vanvy] 轮播组件加载失败'); });
    },

    loadComponentJs: function (src) {
      return new Promise(function (resolve, reject) {
        var s = document.createElement('script');
        s.src = 'vanvy/v2/' + src;
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    }
  };
})();
