/* Vanvy V2 方案: light (🌅 白昼浅色) */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: { id: 'light', carouselTheme: 'light', carousel: 'banner_light' },
    init: function () {
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var s = document.createElement('script');
      s.src = 'vanvy/v2/components/' + this.CONFIG.carousel + '/banner-' + this.CONFIG.carousel.replace('banner_', '') + '.js';
      document.head.appendChild(s);
    }
  };
})();
