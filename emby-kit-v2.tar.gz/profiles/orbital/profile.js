/* Vanvy V2 方案: orbital (🪐 轨道环绕) */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: { id: 'orbital', carouselTheme: 'midnight', carousel: 'banner_orbital' },
    init: function () {
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var s = document.createElement('script');
      s.src = 'vanvy/v2/components/' + this.CONFIG.carousel + '/banner-' + this.CONFIG.carousel.replace('banner_', '') + '.js';
      document.head.appendChild(s);
    }
  };
})();
