/* Vanvy V2 方案: split (📐 分屏深海) */
(function () {
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {
    CONFIG: { id: 'split', carouselTheme: 'ocean', carousel: 'banner_split' },
    init: function () {
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var s = document.createElement('script');
      s.src = 'vanvy/v2/components/' + this.CONFIG.carousel + '/banner-' + this.CONFIG.carousel.replace('banner_', '') + '.js';
      document.head.appendChild(s);
    }
  };
})();
