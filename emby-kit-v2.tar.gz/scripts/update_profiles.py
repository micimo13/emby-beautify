#!/usr/bin/env python3
"""更新所有 profile.js: 加载 carousel-core + 组件 CSS + 组件 JS + 启动"""
import os, re, json

V2 = "/vol1/@apphome/trim.openclaw/data/workspace/emby-kit-v2"

def make_profile_js(pid, carousel, theme):
    # homeswiper 组件文件名特殊 (HomeSwiper.js 大写)
    if carousel == 'banner_homeswiper':
        jsname = 'HomeSwiper'
    else:
        jsname = carousel.replace('banner_', 'banner-')
    return """/* Vanvy V2 方案: {pid} */
(function () {{
  'use strict';
  if (window.VanvyProfile) return;
  window.VanvyProfile = {{
    CONFIG: {{ id: '{pid}', carousel: '{carousel}', carouselTheme: '{theme}' }},
    init: function () {{
      document.documentElement.classList.add('vanvy-aurora-theme-' + this.CONFIG.carouselTheme);
      var self = this;
      // 1. 核心引擎
      this.load('runtime/vanvy-carousel-core.js', function () {{
        // 2. 组件 CSS
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'vanvy/v2/components/{carousel}/style.css';
        document.head.appendChild(link);
        // 3. 组件 JS
        self.load('components/{carousel}/{jsname}.js', function () {{
          // 4. 启动轮播 (等 DOM 就绪 + 核心引擎就绪)
          setTimeout(function () {{
            try {{ window.VanvyCarouselCore.start('{carousel}'); }} catch (e) {{}}
          }}, 300);
        }});
      }});
    }},
    load: function (src, cb) {{
      if (document.querySelector('script[data-vanvy="' + src + '"]')) {{ cb(); return; }}
      var s = document.createElement('script');
      s.src = 'vanvy/v2/' + src;
      s.setAttribute('data-vanvy', src);
      s.onload = cb; s.onerror = cb;
      document.head.appendChild(s);
    }}
  }};
}})();
""".format(pid=pid, carousel=carousel, theme=theme, jsname=jsname)

for pid in sorted(os.listdir(f"{V2}/profiles")):
    pjson = f"{V2}/profiles/{pid}/profile.json"
    pjs = f"{V2}/profiles/{pid}/profile.js"
    if not os.path.exists(pjson): continue
    cfg = json.load(open(pjson))
    carousel = cfg.get("carousel", "banner_cinema")
    theme = cfg.get("carouselTheme", "midnight")
    with open(pjs, "w") as f:
        f.write(make_profile_js(pid, carousel, theme))
    print(f"✅ {pid}/profile.js 已更新 (carousel={carousel}, theme={theme})")
