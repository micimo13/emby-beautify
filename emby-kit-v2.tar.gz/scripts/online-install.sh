#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 在线安装入口
#  ---------------------------------------------------------------------------
#  用法: curl -sL https://emby-beautify.vanvy.top/scripts/online-install.sh | bash
#  流程: 下载 v2 包 → 解压到临时目录 → 调用 install.sh
# =============================================================================

set -u

# 包下载地址 (本地分发)
PKG_URL="https://emby-beautify.vanvy.top/emby-kit-v2.tar.gz"
TMP_DIR="/tmp/vanvy-v2-install"

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   🎨 Vanvy Emby Kit V2 · 在线安装                        ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""

# 1. 下载包
echo "  📥 下载安装包..."
rm -rf "$TMP_DIR" && mkdir -p "$TMP_DIR"
if command -v curl >/dev/null 2>&1; then
  curl -fsSL --connect-timeout 15 --max-time 120 -o "$TMP_DIR/kit.tar.gz" "$PKG_URL" || { echo "  ❌ 下载失败: $PKG_URL"; exit 1; }
else
  wget -q -T 120 -O "$TMP_DIR/kit.tar.gz" "$PKG_URL" || { echo "  ❌ 下载失败: $PKG_URL"; exit 1; }
fi
echo "  ✅ 下载完成 ($(du -h "$TMP_DIR/kit.tar.gz" | cut -f1))"

# 2. 解压
echo "  📦 解压..."
tar xzf "$TMP_DIR/kit.tar.gz" -C "$TMP_DIR" || { echo "  ❌ 解压失败"; exit 1; }
echo "  ✅ 解压完成"

# 3. 进入目录调用 install.sh
cd "$TMP_DIR" || exit 1
if [ -f install.sh ]; then
  exec bash install.sh "$@"
else
  echo "  ❌ 未找到 install.sh, 包结构异常"
  exit 1
fi
