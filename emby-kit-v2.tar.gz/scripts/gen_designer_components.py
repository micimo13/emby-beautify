#!/usr/bin/env python3
"""批量把设计师效果图演进为正式 Emby 轮播组件"""
import re, os, json

V2 = "/vol1/@apphome/trim.openclaw/data/workspace/emby-kit-v2"
PREVIEW = f"{V2}/components/designer/preview"

# 组件配置: id -> (预览html, 标题选择器, 副标题, 海报容器)
COMPONENTS = {
    "banner_glass": {
        "preview": "glass-morphism.html",
        "name": "GLASS 玻璃拟态",
        "title_sel": ".glass-title",
        "sub_sel": ".glass-sub",
        "poster_sel": ".glass-poster",
        "desc_sel": ".glass-desc",
        "thumbs_sel": ".glass-thumbs",
        "root_class": "vanvy-carousel-banner_glass",
        "tag_sel": ".glass-chip"
    },
    "banner_retro": {
        "preview": "retro-vhs.html",
        "name": "RETRO 复古胶片",
        "title_sel": ".retro-title",
        "sub_sel": ".retro-sub",
        "poster_sel": ".retro-poster",
        "desc_sel": ".retro-desc",
        "thumbs_sel": ".retro-thumbs",
        "root_class": "vanvy-carousel-banner_retro"
    },
    "banner_minimal": {
        "preview": "minimal-editorial.html",
        "name": "MINIMAL 极简",
        "title_sel": ".minimal-title",
        "sub_sel": ".minimal-sub",
        "poster_sel": None,
        "desc_sel": ".minimal-desc",
        "thumbs_sel": ".minimal-dots",
        "root_class": "vanvy-carousel-banner_minimal"
    },
    "banner_orbital": {
        "preview": "orbital-space.html",
        "name": "ORBITAL 轨道",
        "title_sel": ".orbital-title",
        "sub_sel": ".orbital-sub",
        "poster_sel": ".orbital-main",
        "desc_sel": ".orbital-desc",
        "thumbs_sel": ".orbital-thumbs",
        "root_class": "vanvy-carousel-banner_orbital"
    },
    "banner_light": {
        "preview": "light-day.html",
        "name": "LIGHT 白昼",
        "title_sel": ".light-title",
        "sub_sel": ".light-sub",
        "poster_sel": ".light-poster",
        "desc_sel": ".light-desc",
        "thumbs_sel": ".light-thumbs",
        "root_class": "vanvy-carousel-banner_light"
    },
    "banner_paper": {
        "preview": "paper-art.html",
        "name": "PAPER 纸艺",
        "title_sel": ".paper-title",
        "sub_sel": ".paper-title-en",
        "poster_sel": ".paper-poster",
        "desc_sel": ".paper-desc",
        "thumbs_sel": ".paper-thumbs",
        "root_class": "vanvy-carousel-banner_paper"
    },
}

def extract_css(preview_file, root_class):
    html = open(preview_file).read()
    m = re.search(r'<style>(.*?)</style>', html, re.S)
    css = m.group(1) if m else ''
    # 移除全局 reset
    css = css.replace('* { margin:0; padding:0; box-sizing:border-box; }', '')
    css = re.sub(r'html,body \{[^}]*\}', '', css)
    # 提取 html/body 级字体族
    font_m = re.search(r'font-family:([^;}]+)', html[:2000])
    font_family = font_m.group(1).strip() if font_m else "'PingFang SC',sans-serif"
    # 提取根 class 名 (第一个主要样式类)
    root_sel = root_class
    # 加作用域: 把裸类选择器包进根
    css = re.sub(r'(?<![\w-])\.([a-z][\w-]*)', rf'.{root_sel} .\1', css)
    # 容器定义
    css = f""".{root_sel} {{
  position:relative; width:100%; height:78vh; min-height:420px; overflow:hidden;
  border-radius:8px; font-family:{font_family};
}}
""" + css
    # 数据驱动补丁: 海报/缩略图背景
    css += f"""
.{root_sel} [data-poster] {{ background-size:cover; background-position:center; }}
.{root_sel} [data-thumb] {{ background-size:cover; background-position:center; }}
.{root_sel} [data-overlay] {{ position:absolute; inset:0; background:linear-gradient(180deg,transparent 50%,rgba(0,0,0,.55)); }}
"""
    return css

def gen_js(comp_id, cfg):
    cname = comp_id.replace('banner_', '')
    cname_pascal = ''.join(w.capitalize() for w in cname.split('_'))
    root_class = cfg['root_class']
    title_sel = cfg.get('title_sel', '')
    sub_sel = cfg.get('sub_sel', '')
    poster_sel = cfg.get('poster_sel')
    desc_sel = cfg.get('desc_sel', '')
    thumbs_sel = cfg.get('thumbs_sel', '')

    # 动态模板: 基于效果图结构生成 (简化版: 标题/副标题/简介/海报/缩略图)
    poster_html = '<div class="v2c-poster" data-poster><div data-overlay></div></div>' if poster_sel else ''
    js = f"""/* Vanvy Emby Kit V2 · {cfg['name']} 轮播组件 (由效果图演进) */
(function () {{
  'use strict';
  if (window.Vanvy{cname_pascal}) return;
  window.Vanvy{cname_pascal} = {{}};

  window.VanvyCarouselCore.register('{comp_id}', {{
    query: {{
      ImageTypes: 'Backdrop',
      EnableImageTypes: 'Backdrop,Primary,Logo',
      IncludeItemTypes: 'Movie,Series',
      SortBy: 'DateCreated',
      Recursive: true,
      Limit: 8,
      Fields: 'ProductionYear,Overview,CommunityRating,Genres',
      EnableUserData: false,
      EnableTotalRecordCount: false
    }},
    render: function (items, root, core) {{
      // 容器结构
      root.innerHTML = '<div class="{root_class}">' +
        '<div class="v2c-slide">' +
        '{poster_html}' +
        '  <div class="v2c-info">' +
        '    <div class="v2c-title"></div>' +
        '    <div class="v2c-sub"></div>' +
        '    <div class="v2c-meta"><span class="v2c-rating">★ </span><span class="v2c-year"></span><span class="v2c-genres"></span></div>' +
        '    <div class="v2c-desc"></div>' +
        '    <div class="v2c-btns">' +
        '      <button class="v2c-btn v2c-play" data-action="play">▶ 播放</button>' +
        '      <button class="v2c-btn v2c-detail" data-action="detail">ⓘ 详情</button>' +
        '    </div>' +
        '  </div>' +
        '</div>' +
        '<div class="v2c-thumbs"></div>' +
      '</div>';

      var idx = 0;
      var titleEl = root.querySelector('.v2c-title');
      var subEl = root.querySelector('.v2c-sub');
      var descEl = root.querySelector('.v2c-desc');
      var ratingEl = root.querySelector('.v2c-rating');
      var yearEl = root.querySelector('.v2c-year');
      var genresEl = root.querySelector('.v2c-genres');
      var posterEl = root.querySelector('[data-poster]');
      var thumbsEl = root.querySelector('.v2c-thumbs');

      function renderSlide(i) {{
        idx = (i + items.length) % items.length;
        var item = items[idx];
        titleEl.textContent = item.Name || '';
        subEl.textContent = (item.OriginalTitle || item.Name || '') + (item.ProductionYear ? ' · ' + item.ProductionYear : '');
        ratingEl.textContent = '★ ' + (item.CommunityRating ? item.CommunityRating.toFixed(1) : 'N/A');
        yearEl.textContent = item.ProductionYear || '';
        genresEl.textContent = (item.Genres || []).slice(0, 2).join(' / ');
        var ov = item.Overview || '';
        descEl.textContent = ov.length > 120 ? ov.slice(0, 120) + '…' : ov;
        if (posterEl) {{
          var u = core.getImageUrl(item, {{ type: 'Primary', maxWidth: 600 }});
          posterEl.style.backgroundImage = 'url("' + u + '")';
        }}
        renderThumbs();
      }}

      function renderThumbs() {{
        thumbsEl.innerHTML = '';
        items.forEach(function (it, i) {{
          var t = document.createElement('div');
          t.className = 'v2c-thumb' + (i === idx ? ' active' : '');
          t.setAttribute('data-thumb', '');
          var u = core.getImageUrl(it, {{ type: 'Backdrop', maxWidth: 220 }});
          t.style.backgroundImage = 'url("' + u + '")';
          t.addEventListener('click', function () {{ renderSlide(i); }});
          thumbsEl.appendChild(t);
        }});
      }}

      root.querySelector('[data-action="play"]').addEventListener('click', function () {{
        var item = items[idx];
        window.location.hash = '#!/item?id=' + item.Id + '&play=true';
      }});
      root.querySelector('[data-action="detail"]').addEventListener('click', function () {{
        var item = items[idx];
        window.location.hash = '#!/item?id=' + item.Id;
      }});

      renderSlide(0);
      var timer = setInterval(function () {{ renderSlide(idx + 1); }}, 8000);
      root.addEventListener('mouseenter', function () {{ clearInterval(timer); }});
      root.addEventListener('mouseleave', function () {{
        timer = setInterval(function () {{ renderSlide(idx + 1); }}, 8000);
      }});
    }}
  }});

  window.Vanvy{cname_pascal}.start = function () {{
    window.VanvyCarouselCore.start('{comp_id}');
  }};
}})();
"""
    return js

for comp_id, cfg in COMPONENTS.items():
    cdir = f"{V2}/components/{comp_id}"
    os.makedirs(cdir, exist_ok=True)
    preview = f"{PREVIEW}/{cfg['preview']}"
    # CSS
    css = extract_css(preview, cfg['root_class'])
    with open(f"{cdir}/style.css", "w") as f:
        f.write(css)
    # JS
    js = gen_js(comp_id, cfg)
    js_name = f"banner-{comp_id.replace('banner_','')}.js"
    with open(f"{cdir}/{js_name}", "w") as f:
        f.write(js)
    print(f"✅ {comp_id}: style.css ({len(css)}B) + {js_name} ({len(js)}B)")

print("\n全部设计师轮播组件化完成!")
