#!/usr/bin/env python3
"""Vanvy V2 效果图生成器: 用 Playwright 渲染 HTML 并截图"""
import sys, os
from playwright.sync_api import sync_playwright

PREVIEW_DIR = "/vol1/@apphome/trim.openclaw/data/workspace/emby-kit-v2/components/designer/preview"
OUT_DIR = "/vol1/@apphome/trim.openclaw/data/workspace/emby-kit-v2/docs/previews"
os.makedirs(OUT_DIR, exist_ok=True)

def shot(page, html_file, out_name, width=1920, height=1080, full=False):
    page.set_viewport_size({'width': width, 'height': height})
    page.goto(f"file://{html_file}", wait_until='networkidle', timeout=30000)
    page.wait_for_timeout(400)
    path = os.path.join(OUT_DIR, out_name)
    page.screenshot(path=path, full_page=full)
    print(f"  ✅ {out_name} ({width}x{height})")
    return path

def main():
    targets = []
    if len(sys.argv) > 1:
        targets = sys.argv[1:]
    with sync_playwright() as p:
        browser = p.chromium.launch(args=['--no-sandbox'])
        page = browser.new_page()
        for f in sorted(os.listdir(PREVIEW_DIR)):
            if not f.endswith('.html'): continue
            name = f[:-5]
            if targets and name not in targets: continue
            print(f"渲染: {name}")
            if name == 'theme-panel':
                shot(page, os.path.join(PREVIEW_DIR, f), '01-theme-panel.png', 1920, 1080)
            else:
                shot(page, os.path.join(PREVIEW_DIR, f), f'{name}.png', 1920, 1080)
        browser.close()
    print("\n全部完成!")

if __name__ == '__main__':
    main()
