#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 卸载/还原
#  ---------------------------------------------------------------------------
#  用法:
#    bash uninstall.sh --container <名> --all      # 卸载全部美化
#    bash uninstall.sh --container <名> --reset     # 完全还原 (清持久化+钩子)
#    bash uninstall.sh --container <名> --restore-pure  # 只还原纯净 html
#    bash uninstall.sh --container <名> --list-backups   # 列备份
# =============================================================================

set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
source "$SCRIPT_DIR/lib/detect.sh"
source "$SCRIPT_DIR/lib/restore.sh"

CONTAINER=""; ALL=0; RESET=0; RESTORE_PURE=0; LIST_BACKUPS=0

while [ $# -gt 0 ]; do
  case "$1" in
    --container) CONTAINER="$2"; shift ;;
    --all) ALL=1 ;;
    --reset) RESET=1 ;;
    --restore-pure) RESTORE_PURE=1 ;;
    --list-backups) LIST_BACKUPS=1 ;;
    --yes|-y) ASSUME_YES=1 ;;
    *) c_warn "忽略未知参数: $1" ;;
  esac
  shift
done

command -v docker >/dev/null 2>&1 || die "未检测到 docker"
[ -z "${CONTAINER:-}" ] && detect_container
detect_dashboard_dir || true
detect_ext_hook

# ── 完全还原 (--reset) ──
reset_emby() {
  c_warn "════════ 完全还原 Emby (恢复出厂状态) ════════"
  [ "${ASSUME_YES:-0}" = "1" ] || confirm "确认完全还原 $CONTAINER?" || die "已取消"
  restore_pure_html
  # 删资源 + 持久化 + 钩子
  docker exec "$CONTAINER" sh -c "
    rm -rf '$DASHBOARD_DIR/vanvy/v2' /config/vanvy-v2
    EXT=/config/config/ext.sh
    [ -f \"\$EXT\" ] && sed -i '/vanvy-v2 持久化部署/,/end vanvy-v2 持久化/d' \"\$EXT\"
  " 2>/dev/null
  c_ok "✅ $CONTAINER 已完全还原!"
  exit 0
}

# ── 卸载全部 (--all) ──
uninstall_all() {
  c_info "卸载全部 Vanvy V2 美化..."
  docker exec "$CONTAINER" sh -c "
    INDEX='$DASHBOARD_DIR/index.html'
    cp \"\$INDEX\" \"/config/backups/emby-beautify/index.html.bak.\$(date +%Y%m%d-%H%M%S)\" 2>/dev/null
    grep -v 'vanvy/v2/' \"\$INDEX\" > \"\$INDEX.tmp\" && mv \"\$INDEX.tmp\" \"\$INDEX\"
    rm -rf '$DASHBOARD_DIR/vanvy/v2'
  " 2>/dev/null
  c_ok "✅ 已卸载全部美化 (保留持久化, 可用 --restore 恢复)"
}

# ── 只还原纯净 html ──
restore_pure_only() {
  restore_pure_html
  c_ok "✅ 纯净 html 已还原 (资源仍在, 如需彻底删除请用 --all)"
}

# ── 主流程 ──
if [ "$LIST_BACKUPS" = "1" ]; then
  c_info "index.html 备份列表:"
  docker exec "$CONTAINER" sh -c "ls -lt /config/backups/emby-beautify/index.html.* 2>/dev/null | head -20" 2>/dev/null
  exit 0
fi
if [ "$RESET" = "1" ]; then reset_emby
elif [ "$ALL" = "1" ]; then uninstall_all
elif [ "$RESTORE_PURE" = "1" ]; then restore_pure_only
else
  c_warn "用法: --all / --reset / --restore-pure / --list-backups"
  exit 1
fi
