#!/usr/bin/env bash
# =============================================================================
#  Vanvy Emby Kit V2 · 主安装器
#  ---------------------------------------------------------------------------
#  用法:
#    curl -sL https://emby-beautify.vanvy.top/scripts/online-install.sh | bash
#    bash install.sh                          # 交互式
#    bash install.sh --container emby-302     # 指定容器
#    bash install.sh --profile cinema-blackgold --yes   # 非交互直装
#    bash install.sh --restore                # 从持久卷恢复
#    bash install.sh --detect-only            # 只检测
#  ---------------------------------------------------------------------------
#  流程: 0检测 → 1基底选择(纯净还原) → 2方案选择 → 3功能微调 → 4品牌 → 5确认部署
# =============================================================================

set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
source "$SCRIPT_DIR/lib/detect.sh"
source "$SCRIPT_DIR/lib/restore.sh"
source "$SCRIPT_DIR/lib/deploy.sh"

# ── 参数解析 ──
CONTAINER=""; PROFILE=""; CLI_FEATURES=""; DETECT_ONLY=0; RESTORE=0; ASSUME_YES=0; INCREMENTAL=0

while [ $# -gt 0 ]; do
  case "$1" in
    --container) CONTAINER="$2"; shift ;;
    --profile)   PROFILE="$2"; shift ;;
    --feature)   CLI_FEATURES="$2"; shift ;;
    --detect-only) DETECT_ONLY=1 ;;
    --restore)   RESTORE=1 ;;
    --incremental) INCREMENTAL=1 ;;
    --yes|-y)    ASSUME_YES=1 ;;
    *) c_warn "忽略未知参数: $1" ;;
  esac
  shift
done

banner() {
  echo ""
  echo "  ╔══════════════════════════════════════════════════════════╗"
  echo "  ║   🎨 Vanvy Emby Kit V2                                   ║"
  echo "  ║   纯净部署 · 方案驱动 · 运行时主题 · 版本自适应           ║"
  echo "  ╚══════════════════════════════════════════════════════════╝"
  echo ""
}

# ── 方案列表 (从 profiles/ 目录动态发现) ──
list_profiles() {
  local i=1
  for d in "$SCRIPT_DIR"/profiles/*/; do
    [ -d "$d" ] || continue
    local id name desc
    id=$(basename "$d")
    name=$(grep -oE '"name":\s*"[^"]*"' "$d/profile.json" 2>/dev/null | head -1 | cut -d'"' -f4)
    desc=$(grep -oE '"desc":\s*"[^"]*"' "$d/profile.json" 2>/dev/null | head -1 | cut -d'"' -f4)
    [ -z "$name" ] && name="$id"
    printf '  │     [%d] %-24s %s\n' "$i" "$name" "${desc:-}"
    PROFILE_IDS[$i]="$id"
    i=$((i+1))
  done
  PROFILE_COUNT=$((i-1))
}

# ── 第 0 步: 环境检测 ──
banner
command -v docker >/dev/null 2>&1 || die "未检测到 docker"
run_health_check || exit 1
print_diagnosis

[ "$DETECT_ONLY" = "1" ] && { c_ok "环境检测完成"; exit 0; }

# ── 第 1 步: 基底选择 (纯净优先, 小白安全) ──
if [ "$RESTORE" = "1" ]; then
  restore_from_persist
  exit $?
fi

pick_baseline() {
  if [ "$INCREMENTAL" = "1" ]; then
    BASE_CHOICE="incremental"
    c_info "已选择: 增量部署 (保留现有 html)"
    ensure_inject_anchor
    return 0
  fi
  [ "$ASSUME_YES" = "1" ] && { BASE_CHOICE="pure"; return 0; }

  echo ""
  echo "  ┌─────────────────────────────────────────────────────────┐"
  echo "  │  📄 部署基底选择 (纯净优先, 小白安全)                    │"
  echo "  ├─────────────────────────────────────────────────────────┤"
  if [ "$HTML_DIRTY" = "1" ]; then
    echo "  │  ⚠️  检测到当前 index.html 已被污染:                    │"
    echo "  │      $HTML_NOTE"
    echo "  │                                                         │"
  else
    echo "  │  ✅ 当前 index.html 纯净                               │"
    echo "  │                                                         │"
  fi
  echo "  │  [1] 🧹 还原纯净 html 再部署 (推荐, 小白安全)           │"
  echo "  │  [2] 🔧 在现有 html 上增量部署 (高级)                   │"
  echo "  │  [3] ❌ 退出 (先去备份/检查)                             │"
  echo "  └─────────────────────────────────────────────────────────┘"
  c_ask "选择 [1-3, 默认 1]: "
  safe_read bsel "1"
  case "$bsel" in
    2) BASE_CHOICE="incremental"; ensure_inject_anchor ;;
    3) die "已退出" ;;
    *) BASE_CHOICE="pure"; restore_pure_html || die "纯净还原失败, 请检查" ;;
  esac
}

pick_baseline

# ── 第 2 步: 方案选择 ──
pick_profile() {
  [ -n "$PROFILE" ] && { c_info "方案: $PROFILE"; return 0; }
  [ "$ASSUME_YES" = "1" ] && { PROFILE="cinema-blackgold"; return 0; }
  echo ""
  echo "  ┌─────────────────────────────────────────────────────────┐"
  echo "  │  🎠 选择部署方案 (按版本自动过滤)                       │"
  declare -A PROFILE_IDS=()
  list_profiles
  echo "  └─────────────────────────────────────────────────────────┘"
  c_ask "选择 [1-$PROFILE_COUNT]: "
  safe_read psel "1"
  if echo "$psel" | grep -qE '^[0-9]+$' && [ "$psel" -ge 1 ] && [ "$psel" -le "$PROFILE_COUNT" ]; then
    PROFILE="${PROFILE_IDS[$psel]}"
  fi
  c_ok "方案: $PROFILE"
}

pick_profile

# ── 第 3 步: 确认部署 ──
echo ""
c_info "即将部署:"
echo "  📦 容器:   $CONTAINER ($IMAGE_TYPE · Emby $VER)"
echo "  🧹 基底:   $([ "$BASE_CHOICE" = "pure" ] && echo '纯净 html' || echo '增量')"
echo "  🎠 方案:   $PROFILE"
[ -n "${CLI_FEATURES:-}" ] && echo "  ⚡ 功能:   $CLI_FEATURES"

if [ "$ASSUME_YES" = "1" ]; then
  confirm_go=1
else
  c_ask "确认部署? [y/N]: "
  safe_read ans "N"
  [ "$ans" = "y" ] || [ "$ans" = "Y" ] && confirm_go=1 || confirm_go=0
fi

if [ "${confirm_go:-0}" = "1" ]; then
  deploy_profile "$PROFILE" || die "部署失败"
  persist_all
  c_ok "🎉 部署完成! 浏览器 Ctrl+F5 强刷查看效果"
  c_info "💡 刷新后右下角出现 🎨 按钮 → 运行时主题面板"
else
  c_warn "已取消"
fi
