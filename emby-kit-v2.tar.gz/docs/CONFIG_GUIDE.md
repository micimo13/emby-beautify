# 🔑 Vanvy Emby Kit V2 — 功能配置获取指引

> 安装时涉及的可选配置项，这里告诉你**去哪里获取**。

## 一、JAV 元数据美化（jav_details）

### JavDB SecretKey（刮削/短评）
1. 打开 https://javdb.com 并**登录**你的账号
2. 进入「设置」→ 找到 **API / SecretKey** 区域
3. 点击「生成」或复制已有的 SecretKey（形如 `xxxxxxxx-xxxx-xxxx`）
4. 粘贴到安装器询问处，或编辑容器内：
   ```
   /system/dashboard-ui/vanvy/features/jav_details/config.json
   ```
   填入 `"javdbSecretKey": "你的key"`

### OpenAI API Key（翻译）
1. 打开 https://platform.openai.com 并登录
2. 右上角头像 → **API keys** → **Create new secret key**
3. 复制 `sk-...` 开头的 key
4. 填入 `"openaiApiKey": "sk-..."`

> 💡 无 OpenAI Key 也可用，只是番号/简介翻译功能不可用，其他正常。

## 二、弹幕（danmaku）

- **开箱即用**：默认使用弹弹play 源，无需任何配置
- **Bangumi Token（可选，仅单集收藏同步）**：
  1. 打开 https://next.bgm.tv/demo/access-token
  2. 授权登录后生成 Access Token
  3. 在 Emby 播放页 → 弹幕设置面板 → 粘贴 Token（存浏览器本地）

## 三、豆瓣/Bangumi 评分（douban）

- **开箱即用**：自动抓取豆瓣/Bangumi 评分，无需配置
- 若评分不显示：检查服务器能否访问 douban.com / bangumi.tv（可能需要代理）

## 四、第三方播放器（localplayer）

- 配置 PotPlayer / mpv 的**协议关联**（播放器侧）：
  - PotPlayer：设置 → 关联 → 注册 `potplayer://` 协议
  - mpv：安装 mpv 后注册 `mpv://` 协议
- Emby 播放页点「外部播放」按钮时自动调用

## 五、品牌定制（branding）

安装时填写图片 URL：
- **加载页 LOGO**：任意外链图片 URL（建议 512x512 PNG）
- **浏览器标签图标**：favicon URL（建议 64x64 .ico 或 PNG）
- 图片会被下载到容器持久化，无需持续外链

## 六、其他

| 项 | 说明 |
|---|---|
| 远程路径助手 | 开箱即用，详情页显示资源路径 |
| 播放页增强 | 开箱即用，OSD/音量条适配 |
| 全局字体 | 双 CDN 回退，无需配置 |
| Fluent 布局 | 开箱即用，侧边栏浮层/透明顶栏 |

---

## 配置后需要重启吗？

- **config.json**（JAV）：改完 Ctrl+F5 强刷即可
- **浏览器侧**（Bangumi Token）：刷新页面即可
- **容器级**（品牌 LOGO）：刷新页面即可

> 所有配置**不需要重启容器**，刷新页面即生效。
