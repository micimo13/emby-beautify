# 📋 Vanvy Emby Kit V2 — 项目管理章程 (PM)

> 项目经理: 虾子🦐 | 立项: 2026-08-15 | 汇报对象: 主人 Marnie✨✨🎊
> 部署方式: `curl -sL https://emby-beautify.vanvy.top/scripts/online-install.sh | bash`

## 一、项目目标
将 v1 (emby-kit, 800M→19M, 修修补补架构脆弱) 重构为 v2 (emby-kit-v2):
- 单点注入架构 (一行 loader 管理一切, 根治注入/卸载/冲突)
- 皮肤激活引擎 (用户媒体路由白名单, 根治设置页黑/残留)
- 纯净 html 优先 (小白安全, 4级还原来源)
- 14 款轮播 + 运行时主题面板 + 13 功能 + 版本自适应 + 品牌 + 一键还原

## 二、团队角色分工 (虚拟团队, 我一人分饰多角)

| 角色 | 负责人 | 职责 | 交付物 |
|---|---|---|---|
| 🧑💼 项目经理 | 虾子🦐 | 规划/协调/里程碑/风险/终审汇报 | 本章程 + 周报 |
| 🎨 UI/UX 设计师 | 虾子🦐 | 轮播美术/面板交互/效果图 | 8张效果图 ✅ 已完成 |
| 💻 前端工程师 | 虾子🦐 | loader/skin引擎/主题面板/轮播组件 | runtime/ + components/ |
| ⚙️ Shell工程师 | 虾子🦐 | 安装器/检测/部署/持久化/卸载 | install.sh + lib/ |
| 🧪 QA测试工程师 | 虾子🦐 | Playwright自动化/版本兼容/回归 | test/ + 测试报告 |
| 📚 文档工程师 | 虾子🦐 | 使用文档/配置获取指引 | docs/ |

## 三、里程碑与任务卡 (WBS)

### M0 — 立项与设计 ✅ (已完成)
- [x] 调研 v1 全部组件/坑 (版本兼容/纯净度/冲突矩阵)
- [x] 效果图 8 张 (面板 + 7款原创轮播) 待主人验收
- [x] 思路定稿 (14轮播/面板/纯净还原/版本矩阵)

### M1 — P0 地基 (当前执行)
- [ ] 1.1 detect.sh — 环境检测 (容器/镜像/版本/纯净度诊断)
- [ ] 1.2 restore.sh — 纯净 html 还原引擎 (4级来源)
- [ ] 1.3 vanvy-loader.js — 单点加载器 (读 data-profile 动态加载)
- [ ] 1.4 vanvy-skin.js — 皮肤激活引擎 (路由白名单, 零内联残留)
- [ ] 1.5 install.sh — 主安装器 (0检测→1基底→2方案→3功能→4品牌→5确认)
- [ ] 1.6 uninstall.sh — 一键卸载/还原
- [ ] 1.7 QA: curl|bash 全流程闭环测试 (emby-302 真实环境)
- ⚡ 里程碑: `curl|bash` 可跑通装/卸/还原

### M2 — P1 首个完整方案
- [ ] 2.1 cinema-blackgold 方案 (CINEMA轮播 + 黑金 + 石墨毛玻璃 + dark_skin)
- [ ] 2.2 主题面板 runtime (右下角🎨按钮, 10模块, CSS变量实时调)
- [ ] 2.3 11个主力功能接入 (JAV/弹幕/豆瓣/倍速/播放器/播放页/Fluent/字体/详情/远程路径)
- [ ] 2.4 QA: 面板调参持久化 + 设置页/首页切换回归
- ⚡ 里程碑: 影院黑金方案完整可用

### M3 — P2 方案扩展
- [ ] 3.1 aurora/split/neo/glass/retro/minimal/orbital/light 方案
- [ ] 3.2 CRX/HomeSwiper 变种接入 (跨版本)
- [ ] 3.3 品牌增强 (LOGO/favicon/启动动画)
- [ ] 3.4 QA: 14款方案 × 4.8/4.9 兼容矩阵测试

### M4 — P3 发布
- [ ] 4.1 打包 → 部署 emby-beautify.vanvy.top
- [ ] 4.2 在线安装脚本 (online-install.sh)
- [ ] 4.3 全量回归 + 文档 + 配置获取指引
- [ ] 4.4 主人终验收 → 正式交付

## 四、质量门禁 (每个里程碑过 QA 才能进下一个)
1. bash -n 语法检查全过
2. node --check JS 全过
3. Playwright 关键场景回归 (首页黑化/设置页还原/切换无残留)
4. 真实容器部署验证 (emby-302)
5. 三端同步 (容器/本地分发/GitHub)

## 五、风险登记册
| 风险 | 等级 | 缓解 |
|---|---|---|
| Emby 版本差异导致注入失效 | 高 | detect 版本识别 + 方案版本过滤 + 纯净html兜底 |
| 视图缓存/路由残留 | 高 | 白名单路由 + 零内联样式 (v1 v5 已验证方案) |
| 容器重建丢美化 | 中 | 持久化 /config/vanvy-v2/ + amilys钩子 |
| 大文件 GitHub 推送 401 | 低 | curl --data-binary (v1 已验证) |
| 私有域名泄露 | 高 | sync_github.sh --check + 转换 (v1 铁律) |

## 六、汇报机制
- 每个里程碑完成 → QA 报告 → PM 审查 → 向主人汇报
- 主人随时可查看 docs/progress.md 进度

## 📊 M2 完成报告 (2026-08-15 23:15)
- 主题面板 (vanvy-panel.js/css): FAB + 侧边面板 10 模块, CSS变量实时调参, localStorage持久化
- QA: Playwright 模拟环境全链路通过 (调色→--vanvy-accent-2 实时变)
- 真实部署 emby-302: loader/skin/panel/profile 全加载, skinActive=True, 面板真实打开, 深色皮肤生效
- 快照: emby-302 index.html + vanvy 目录 pre-v2 备份
- 状态: M2 达成 ✅ 进 M3 (方案扩展)
