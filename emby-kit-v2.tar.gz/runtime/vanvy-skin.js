/* ═══════════════════════════════════════════════════════════
   Vanvy Emby Kit V2 · 皮肤激活引擎 (vanvy-skin)
   ───────────────────────────────────────────────────────────
   架构: 用户媒体路由白名单激活 (v1 v5 最终验证的正确方案)
   - 只在用户媒体/浏览路由激活 html.vanvy-skin-active
   - 管理路由 (settings/dashboard/plugins...) 不激活 → 天然零黑化
   - 零内联样式: 只维护 class, 不写 style 属性 → 杜绝残留 bug
   - 兼容 hashbang (#!/) 和 hash (#/) 路由
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.VanvySkin) return;
  window.VanvySkin = {
    ACTIVE_CLASS: 'vanvy-skin-active',
    // 用户媒体/浏览路由白名单 (base route, 去 .html 后缀)
    // 注意: users = 用户个人资料页(用户界面), 不是管理后台!
    USER_ROUTES: [
      'home', 'movies', 'tvshows', 'shows', 'series',
      'books', 'boxsets', 'games', 'kids', 'livetv',
      'playlists', 'search', 'list', 'folders', 'videos',
      'music', 'news', 'newepisodes', 'onnow', 'recordedtv',
      'programs', 'sports', 'latest', 'users', 'person',
      'item', 'details', 'watch', 'mylist', 'favorites'
    ],

    /** 解析 hashbang/hash 路由的 base */
    parseRoute: function () {
      try {
        var h = location.hash || '';
        var route = h.replace(/^#!?\//, '').split('?')[0].split('#')[0].toLowerCase();
        return route.split('.')[0];
      } catch (e) { return ''; }
    },

    /** 是否用户媒体路由 (白名单) */
    isUserRoute: function () {
      var route = this.parseRoute();
      if (!route) return false; // 空路由(登录页)不激活
      for (var i = 0; i < this.USER_ROUTES.length; i++) {
        if (route === this.USER_ROUTES[i] || route.indexOf(this.USER_ROUTES[i] + '/') === 0) {
          return true;
        }
      }
      return false;
    },

    /** 维护 html.vanvy-skin-active 标记 */
    mark: function () {
      var active = this.isUserRoute();
      var root = document.documentElement;
      try {
        if (active) root.classList.add(this.ACTIVE_CLASS);
        else root.classList.remove(this.ACTIVE_CLASS);
      } catch (e) {}
      return active;
    },

    /** 应用当前激活状态 */
    apply: function () {
      // 只维护 class, 不写任何内联样式 (杜绝残留)
      this.mark();
    },

    /** 初始化 */
    init: function () {
      this.apply();
      var self = this;
      window.addEventListener('hashchange', function () { self.apply(); });
      setInterval(function () { self.apply(); }, 2000);
    }
  };
})();
