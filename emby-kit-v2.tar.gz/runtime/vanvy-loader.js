/* ═══════════════════════════════════════════════════════════
   Vanvy Emby Kit V2 · 单点加载器 (vanvy-loader)
   ───────────────────────────────────────────────────────────
   index.html 只注入这一个 script, 由它动态加载:
     1. themes.css      — CSS 变量体系 (主题参数)
     2. vanvy-skin.js   — 皮肤激活引擎 (路由白名单)
     3. vanvy-panel.js  — 运行时主题面板 (右下角🎨)
     4. profile 资源    — 该方案的轮播/功能组件
   配置来源: <script data-profile="xxx"> 或 localStorage
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.VanvyV2Loaded) return;
  window.VanvyV2Loaded = true;

  var BASE = 'vanvy/v2/';

  /** 读取当前方案 (扫 data-profile 属性, 不依赖 currentScript) */
  function getProfile() {
    var profile = null;
    try {
      // 扫所有 script 标签找 data-profile
      var scripts = document.querySelectorAll('script[data-profile]');
      for (var i = 0; i < scripts.length; i++) {
        var p = scripts[i].getAttribute('data-profile');
        if (p) { profile = p; break; }
      }
    } catch (e) {}
    if (!profile) {
      try { profile = localStorage.getItem('vanvy-v2-profile') || 'cinema-blackgold'; } catch (e) {}
    } else {
      try { localStorage.setItem('vanvy-v2-profile', profile); } catch (e) {}
    }
    return profile;
  }

  var PROFILE = getProfile();
  try { localStorage.setItem('vanvy-v2-profile', PROFILE); } catch (e) {}

  /** 加载 css */
  function loadCss(href) {
    if (document.querySelector('link[data-vanvy="' + href + '"]')) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = BASE + href;
      link.setAttribute('data-vanvy', href);
      link.onload = resolve;
      link.onerror = reject;
      document.head.appendChild(link);
    });
  }

  /** 加载 js */
  function loadJs(src) {
    if (document.querySelector('script[data-vanvy="' + src + '"]')) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = BASE + src;
      s.setAttribute('data-vanvy', src);
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  /** 主流程 */
  function boot() {
    // 1. 核心: 主题变量 + 皮肤引擎 + 面板
    return Promise.all([
      loadCss('runtime/themes.css').catch(function () {}),
      loadCss('runtime/vanvy-panel.css').catch(function () {}),
      loadJs('runtime/vanvy-skin.js').catch(function () {}),
      loadJs('runtime/vanvy-panel.js').catch(function () {})
    ]).then(function () {
      // 2. 方案资源
      var profileJs = 'profiles/' + PROFILE + '/profile.js';
      return loadJs(profileJs).catch(function () {
        console.warn('[Vanvy] profile 加载失败:', PROFILE);
      });
    }).then(function () {
      // 3. 通知皮肤引擎启动
      if (window.VanvySkin) window.VanvySkin.init();
      if (window.VanvyPanel) window.VanvyPanel.init();
      if (window.VanvyProfile) window.VanvyProfile.init();
      console.log('[Vanvy V2] 已加载方案:', PROFILE);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
