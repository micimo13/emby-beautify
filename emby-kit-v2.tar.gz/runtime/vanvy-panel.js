/* ═══════════════════════════════════════════════════════════
   Vanvy Emby Kit V2 · 运行时主题面板 (vanvy-panel)
   ───────────────────────────────────────────────────────────
   右下角 🎨 悬浮按钮 → 侧边面板实时调参
   全 CSS 变量驱动: document.documentElement.style.setProperty()
   localStorage 持久化 + 每用户独立 + 导出/导入 JSON
   零内联残留: 只改变量, 不碰 Emby 结构, 卸载即还原
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.VanvyPanel) return;

  var LS_KEY = 'vanvy-v2-panel-config';

  // ── 默认配置 ──
  var DEFAULTS = {
    accent: '#f5c518',        // 主题色
    themeMode: 'dark',        // dark | light | auto | purple | amber | graphite
    border: 'thin',           // none | thin | thick
    radius: 'default',        // none | small | default | large | xlarge
    shadow: 55,               // 0-100
    glassAlpha: 70,           // 0-100
    glassBlur: 18,            // px
    cardStyle: 'glass',       // flat | 3d | glass | blackgold
    layout: 'fold',           // vertical | fold | horizontal
    fontScale: 100            // 90-130
  };

  var state = {};
  var panelEl = null;
  var fabEl = null;

  // ── 加载/保存配置 ──
  function load() {
    try {
      var saved = JSON.parse(localStorage.getItem(LS_KEY) || '{}');
      state = Object.assign({}, DEFAULTS, saved);
    } catch (e) { state = Object.assign({}, DEFAULTS); }
  }
  function save() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) {}
  }

  // ── CSS 变量映射 ──
  function apply() {
    var root = document.documentElement;
    root.style.setProperty('--vanvy-accent-2', state.accent);

    // 圆角
    var radiusMap = { none: '0px', small: '6px', default: '14px', large: '20px', xlarge: '28px' };
    root.style.setProperty('--vanvy-card-radius', radiusMap[state.radius] || '14px');

    // 边框
    var borderMap = { none: '0px', thin: '1px', thick: '3px' };
    root.style.setProperty('--vanvy-card-border', borderMap[state.border] || '0px');

    // 阴影
    root.style.setProperty('--vanvy-card-shadow', (state.shadow / 100).toFixed(2));

    // 毛玻璃
    root.style.setProperty('--vanvy-glass-alpha', (state.glassAlpha / 100).toFixed(2));
    root.style.setProperty('--vanvy-glass-blur', state.glassBlur + 'px');

    // 卡片风格
    var cardBgMap = {
      flat: '#151518',
      '3d': '#1a1a1f',
      glass: 'rgba(21,21,24,0.75)',
      blackgold: 'linear-gradient(160deg,#1c1408,#0f0a04)'
    };
    root.style.setProperty('--vanvy-card-bg', cardBgMap[state.cardStyle] || '#151518');

    // 字号
    root.style.setProperty('--vanvy-font-scale', state.fontScale + '%');

    // 主题模式 → 亮色模式时覆盖背景
    if (state.themeMode === 'light') {
      root.style.setProperty('--vanvy-bg', '#f5f4f0');
      root.style.setProperty('--vanvy-bg-2', '#efe8d8');
      root.style.setProperty('--vanvy-text', '#111');
    } else {
      root.style.setProperty('--vanvy-bg', '#0a0a0c');
      root.style.setProperty('--vanvy-bg-2', '#050506');
      root.style.setProperty('--vanvy-text', '#e7e5e4');
    }
  }

  // ── 构建面板 DOM ──
  function buildPanel() {
    panelEl = document.createElement('div');
    panelEl.className = 'vanvy-panel';
    panelEl.innerHTML = '' +
      '<div class="vanvy-panel-head">' +
      '  <span class="vanvy-panel-title">🎨 主题定制</span>' +
      '  <span class="vanvy-panel-close">✕</span>' +
      '</div>' +
      '<div class="vanvy-panel-body">' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">色调</div>' +
      '    <div class="vanvy-swatches">' +
      '      <div class="vanvy-swatch" data-accent="#a78bfa" style="background:#a78bfa"></div>' +
      '      <div class="vanvy-swatch" data-accent="#f5c518" style="background:#f5c518"></div>' +
      '      <div class="vanvy-swatch" data-accent="#34d399" style="background:#34d399"></div>' +
      '      <div class="vanvy-swatch" data-accent="#f472b6" style="background:#f472b6"></div>' +
      '      <div class="vanvy-swatch" data-accent="#22d3ee" style="background:#22d3ee"></div>' +
      '      <div class="vanvy-swatch" data-accent="#f59e0b" style="background:#f59e0b"></div>' +
      '      <input type="color" class="vanvy-color-picker" value="#f5c518" title="自定义">' +
      '    </div>' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">主题</div>' +
      '    <div class="vanvy-opts">' +
      '      <button class="vanvy-opt" data-theme="dark">🌙 深色</button>' +
      '      <button class="vanvy-opt" data-theme="light">☀️ 浅色</button>' +
      '      <button class="vanvy-opt" data-theme="auto">🔄 跟随</button>' +
      '      <button class="vanvy-opt" data-theme="purple">🔮 幻紫</button>' +
      '      <button class="vanvy-opt" data-theme="amber">🟠 琥珀</button>' +
      '      <button class="vanvy-opt" data-theme="graphite">🖤 石墨</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">边框</div>' +
      '    <div class="vanvy-opts">' +
      '      <button class="vanvy-opt" data-border="none">无</button>' +
      '      <button class="vanvy-opt" data-border="thin">细</button>' +
      '      <button class="vanvy-opt" data-border="thick">粗</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">圆角</div>' +
      '    <div class="vanvy-opts">' +
      '      <button class="vanvy-opt" data-radius="none">无</button>' +
      '      <button class="vanvy-opt" data-radius="small">小</button>' +
      '      <button class="vanvy-opt" data-radius="default">默认</button>' +
      '      <button class="vanvy-opt" data-radius="large">大</button>' +
      '      <button class="vanvy-opt" data-radius="xlarge">超大</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">阴影 <span class="vanvy-val" data-for="shadow"></span></div>' +
      '    <input type="range" class="vanvy-slider" data-key="shadow" min="0" max="100">' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">毛玻璃 <span class="vanvy-val" data-for="glassAlpha"></span></div>' +
      '    <input type="range" class="vanvy-slider" data-key="glassAlpha" min="0" max="100">' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">卡片风格</div>' +
      '    <div class="vanvy-opts">' +
      '      <button class="vanvy-opt" data-card="flat">扁平</button>' +
      '      <button class="vanvy-opt" data-card="3d">立体</button>' +
      '      <button class="vanvy-opt" data-card="glass">玻璃</button>' +
      '      <button class="vanvy-opt" data-card="blackgold">黑金</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">布局</div>' +
      '    <div class="vanvy-opts">' +
      '      <button class="vanvy-opt" data-layout="vertical">垂直</button>' +
      '      <button class="vanvy-opt" data-layout="fold">折叠</button>' +
      '      <button class="vanvy-opt" data-layout="horizontal">水平</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="vanvy-mod">' +
      '    <div class="vanvy-mod-label">字号 <span class="vanvy-val" data-for="fontScale"></span></div>' +
      '    <input type="range" class="vanvy-slider" data-key="fontScale" min="90" max="130">' +
      '  </div>' +
      '</div>' +
      '<div class="vanvy-panel-foot">' +
      '  <button class="vanvy-btn vanvy-btn-save">💾 保存</button>' +
      '  <button class="vanvy-btn vanvy-btn-reset">↺ 重置</button>' +
      '  <button class="vanvy-btn vanvy-btn-export">📤 导出</button>' +
      '  <button class="vanvy-btn vanvy-btn-import">📥 导入</button>' +
      '</div>';

    // FAB 按钮
    fabEl = document.createElement('div');
    fabEl.className = 'vanvy-fab';
    fabEl.textContent = '🎨';
    fabEl.title = '主题定制';

    document.body.appendChild(fabEl);
    document.body.appendChild(panelEl);

    bindEvents();
    refreshUI();
  }

  function bindEvents() {
    // FAB 开关
    fabEl.addEventListener('click', function () {
      panelEl.classList.toggle('vanvy-panel-open');
    });
    panelEl.querySelector('.vanvy-panel-close').addEventListener('click', function () {
      panelEl.classList.remove('vanvy-panel-open');
    });

    // 色块
    panelEl.querySelectorAll('.vanvy-swatch').forEach(function (sw) {
      sw.addEventListener('click', function () {
        state.accent = sw.getAttribute('data-accent');
        apply(); refreshUI();
      });
    });
    // 取色器
    var picker = panelEl.querySelector('.vanvy-color-picker');
    picker.addEventListener('input', function () {
      state.accent = picker.value;
      apply(); refreshUI();
    });

    // 单选组
    panelEl.querySelectorAll('.vanvy-opt').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = null, val = null;
        if (btn.hasAttribute('data-theme')) { key = 'themeMode'; val = btn.getAttribute('data-theme'); }
        else if (btn.hasAttribute('data-border')) { key = 'border'; val = btn.getAttribute('data-border'); }
        else if (btn.hasAttribute('data-radius')) { key = 'radius'; val = btn.getAttribute('data-radius'); }
        else if (btn.hasAttribute('data-card')) { key = 'cardStyle'; val = btn.getAttribute('data-card'); }
        else if (btn.hasAttribute('data-layout')) { key = 'layout'; val = btn.getAttribute('data-layout'); }
        if (key) { state[key] = val; apply(); refreshUI(); }
      });
    });

    // 滑块
    panelEl.querySelectorAll('.vanvy-slider').forEach(function (sl) {
      sl.addEventListener('input', function () {
        state[sl.getAttribute('data-key')] = parseInt(sl.value, 10);
        apply(); refreshUI();
      });
    });

    // 底部按钮
    panelEl.querySelector('.vanvy-btn-save').addEventListener('click', function () {
      save();
      var t = this; t.textContent = '✅ 已保存';
      setTimeout(function () { t.textContent = '💾 保存'; }, 1500);
    });
    panelEl.querySelector('.vanvy-btn-reset').addEventListener('click', function () {
      state = Object.assign({}, DEFAULTS);
      localStorage.removeItem(LS_KEY);
      apply(); refreshUI();
    });
    panelEl.querySelector('.vanvy-btn-export').addEventListener('click', function () {
      var blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'vanvy-theme-config.json';
      a.click();
    });
    panelEl.querySelector('.vanvy-btn-import').addEventListener('click', function () {
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.onchange = function () {
        var f = input.files[0];
        if (!f) return;
        var reader = new FileReader();
        reader.onload = function () {
          try {
            var cfg = JSON.parse(reader.result);
            state = Object.assign({}, DEFAULTS, cfg);
            save(); apply(); refreshUI();
          } catch (e) { alert('配置格式错误'); }
        };
        reader.readAsText(f);
      };
      input.click();
    });
  }

  // ── 刷新 UI 选中态 ──
  function refreshUI() {
    // 色块
    panelEl.querySelectorAll('.vanvy-swatch').forEach(function (sw) {
      sw.classList.toggle('vanvy-active', sw.getAttribute('data-accent') === state.accent);
    });
    // 单选组
    var map = {
      themeMode: 'data-theme', border: 'data-border', radius: 'data-radius',
      cardStyle: 'data-card', layout: 'data-layout'
    };
    Object.keys(map).forEach(function (key) {
      panelEl.querySelectorAll('.vanvy-opt[' + map[key] + ']').forEach(function (btn) {
        btn.classList.toggle('vanvy-active', btn.getAttribute(map[key]) === state[key]);
      });
    });
    // 滑块
    panelEl.querySelectorAll('.vanvy-slider').forEach(function (sl) {
      var k = sl.getAttribute('data-key');
      sl.value = state[k];
      var v = panelEl.querySelector('.vanvy-val[data-for="' + k + '"]');
      if (v) v.textContent = k === 'fontScale' ? state[k] + '%' : state[k];
    });
  }

  // ── 初始化 ──
  window.VanvyPanel = {
    init: function () {
      load();
      apply();
      buildPanel();
    }
  };
})();
