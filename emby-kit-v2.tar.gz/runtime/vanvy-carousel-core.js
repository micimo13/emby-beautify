/* ═══════════════════════════════════════════════════════════
   Vanvy Emby Kit V2 · 轮播核心引擎 (carousel-core)
   ───────────────────────────────────────────────────────────
   通用: 首页路由监听 / 挂载管理 / Emby API 数据获取 / 图片URL
   设计师组件只需实现 render(items, root) 渲染自己的模板
   用法:
     VanvyCarouselCore.register('banner_neo', {
       query: {...},           // 覆盖默认查询
       render: function(items, root) { root.innerHTML = ... }
     })
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.VanvyCarouselCore) return;

  var COMPONENTS = {};

  window.VanvyCarouselCore = {
    /** 注册轮播组件 */
    register: function (id, config) {
      COMPONENTS[id] = config;
    },

    /** 等待 Emby ApiClient 就绪 */
    waitApi: function () {
      return new Promise(function (resolve) {
        if (window.ApiClient) return resolve(window.ApiClient);
        var t = setInterval(function () {
          if (window.ApiClient) { clearInterval(t); resolve(window.ApiClient); }
        }, 100);
        setTimeout(function () { clearInterval(t); resolve(window.ApiClient || null); }, 15000);
      });
    },

    /** 获取数据 */
    getItems: function (query) {
      var self = this;
      return new Promise(function (resolve) {
        self.waitApi().then(function (client) {
          if (!client || !client.getCurrentUserId) return resolve({ Items: [] });
          try {
            client.getItems(client.getCurrentUserId(), query)
              .then(function (data) { resolve(data || { Items: [] }); })
              .catch(function () { resolve({ Items: [] }); });
          } catch (e) { resolve({ Items: [] }); }
        });
      });
    },

    /** 图片 URL (Emby ApiClient.getImageUrl) */
    getImageUrl: function (item, opts) {
      var type = opts.type || 'Backdrop';
      var maxWidth = opts.maxWidth || 1280;
      try {
        if (window.ApiClient && window.ApiClient.getImageUrl) {
          return window.ApiClient.getImageUrl(item, {
            type: type,
            maxWidth: maxWidth,
            tag: (item.ImageTags && item.ImageTags[type]) || undefined
          });
        }
      } catch (e) { /* ignore */ }
      // 兜底: 直拼 URL
      var base = (window.ApiClient && window.ApiClient.serverAddress) ? window.ApiClient.serverAddress() : '';
      return base + '/emby/Items/' + item.Id + '/Images/' + type + '?maxWidth=' + maxWidth;
    },

    /** 挂载轮播到首页首位 */
    mount: function (id, rootEl) {
      var cfg = COMPONENTS[id];
      if (!cfg) return;
      var self = this;
      var query = cfg.query || {
        ImageTypes: 'Backdrop',
        EnableImageTypes: 'Backdrop,Primary,Logo',
        IncludeItemTypes: 'Movie,Series',
        SortBy: 'SortName,ProductionYear',
        Recursive: true,
        Limit: 8,
        Fields: 'ProductionYear,Overview,CommunityRating,Genres,MediaSources',
        EnableUserData: false,
        EnableTotalRecordCount: false
      };
      this.getItems(query).then(function (data) {
        var items = (data && data.Items) ? data.Items : [];
        if (!items.length) { rootEl.remove(); return; }
        try {
          cfg.render(items, rootEl, self);
        } catch (e) {
          console.warn('[VanvyCarousel] render error:', id, e);
          rootEl.remove();
        }
      });
    },

    /** 启动轮播 (profile 调用): 监听首页路由, 挂载/清理 */
    start: function (id) {
      var startedKey = 'VanvyCarousel_' + id + '_started';
      if (window[startedKey]) return;
      window[startedKey] = true;

      var self = this;
      var lastUrl = window.location.href;

      function cleanup() {
        document.querySelectorAll('.view:not(.hide) .vanvy-carousel-' + id).forEach(function (el) {
          if (el.parentNode) el.parentNode.removeChild(el);
        });
      }

      setInterval(function () {
        if (window.location.href !== lastUrl) {
          lastUrl = window.location.href;
          if (window.location.href.indexOf('!/home') === -1) cleanup();
        }
        var onHome = window.location.href.indexOf('!/home') !== -1;
        if (!onHome) { cleanup(); return; }
        // 清理隐藏视图残留
        document.querySelectorAll('.hide .vanvy-carousel-' + id).forEach(function (el) { el.remove(); });
        // 挂载条件: 容器出现 (兼容 .view 包裹 或 裸容器) + 轮播不在
        var container = document.querySelector('.view:not(.hide) .homeSectionsContainer, .view:not(.hide) .sections, .homeSectionsContainer, .sections');
        if (!container) return;
        // 若容器在隐藏视图内则跳过
        if (container.closest && container.closest('.hide')) return;
        if (document.querySelector('.vanvy-carousel-' + id)) return;
        var root = document.createElement('div');
        root.className = 'vanvy-carousel-' + id;
        container.insertBefore(root, container.firstChild);
        self.mount(id, root);
      }, 150);
    }
  };
})();
